/**
 * Solo Night Roulette service worker — instant load, fully offline after the first visit.
 *
 * Cache rules
 *   Page loads (navigations) → cached app shell, never waits on the network.
 *                              The app uses hash routes, so every page is the same index.html.
 *   App files (SHELL)        → precache, cache-first. Versioned: a new VERSION downloads a full
 *                              new set in the background, and the old set stays in use until the
 *                              user taps "Refresh", so a session never mixes versions.
 *   Range requests           → answered from the precache (the keep-awake video), so they work offline.
 *   Other same-origin GETs   → stale-while-revalidate in a small, size-capped runtime cache.
 *   Cross-origin / non-GET   → not touched (the app makes no such requests).
 *
 * Cache names use the "snr-" prefix so this app never deletes the caches of another
 * Fête Studio app hosted on the same domain (Digital Sunset uses "fete-").
 *
 * Deploying: bump VERSION and keep SHELL in sync (`npm run check` verifies it).
 */
const VERSION = 'v9';
const SHELL_CACHE = `snr-shell-${VERSION}`;
const RUNTIME_CACHE = 'snr-runtime';
const RUNTIME_MAX_ENTRIES = 60;

const SHELL = [
  './',
  'LICENSE.txt',
  'manifest.json',
  'assets/icons/icon.svg',
  'assets/icons/icon-maskable.svg',
  'assets/icons/icon-192.png',
  'assets/icons/icon-512.png',
  'assets/icons/icon-maskable-192.png',
  'assets/icons/icon-maskable-512.png',
  'assets/icons/apple-touch-icon-120.png',
  'assets/icons/apple-touch-icon-152.png',
  'assets/icons/apple-touch-icon-167.png',
  'assets/icons/apple-touch-icon-180.png',
  'assets/media/keep-awake.mp4',
  'assets/media/keep-awake.webm',
  'src/css/tokens.css',
  'src/css/base.css',
  'src/css/utilities.css',
  'src/css/components.css',
  'src/css/roulette.css',
  'src/css/night.css',
  'src/js/main.js',
  'src/js/core/clock.js',
  'src/js/core/dom.js',
  'src/js/core/router.js',
  'src/js/core/session.js',
  'src/js/core/store.js',
  'src/js/core/sw-register.js',
  'src/js/core/toast.js',
  'src/js/data/blocks.js',
  'src/js/features/ambient.js',
  'src/js/features/install.js',
  'src/js/features/library.js',
  'src/js/features/lockdown.js',
  'src/js/features/lockscreen.js',
  'src/js/features/night-runner.js',
  'src/js/features/planner.js',
  'src/js/features/ritual-timer.js',
  'src/js/features/theme.js',
  'src/js/features/wake-lock.js',
  'src/js/views/icons.js',
  'src/js/views/night.js',
  'src/js/views/nights.js',
  'src/js/views/not-found.js',
  'src/js/views/pick.js',
  'src/js/views/plan.js',
];

const SHELL_URL = new URL('./', self.registration.scope).href;

self.addEventListener('install', (event) => {
  // cache: 'reload' skips the HTTP cache so a new version never precaches stale files.
  event.waitUntil(
    caches.open(SHELL_CACHE).then((cache) => cache.addAll(SHELL.map((url) => new Request(url, { cache: 'reload' })))),
  );
  // No skipWaiting() here: an update waits until the page asks for it (see sw-register.js).
  // The very first install has no previous worker, so it activates immediately anyway.
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => keys.filter((key) => key.startsWith('snr-shell-') && key !== SHELL_CACHE))
      .then((stale) => Promise.all(stale.map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (request.headers.has('range')) {
    event.respondWith(rangeFromCache(request));
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith(appShell(request));
  } else if (url.href !== self.location.href) {
    event.respondWith(precachedOrRuntime(event));
  }
});

async function appShell(request) {
  // Any other path (a mistyped or old link) would break the shell's relative asset URLs,
  // so send it to the root. Browsers carry the #hash route across the redirect.
  const { pathname } = new URL(request.url);
  const root = new URL(SHELL_URL).pathname;
  if (pathname !== root && pathname !== `${root}index.html`) return Response.redirect(SHELL_URL, 302);

  const cache = await caches.open(SHELL_CACHE);
  const cached = await cache.match(SHELL_URL);
  if (cached) return cached;
  try {
    return await fetch(request);
  } catch {
    return offlinePage();
  }
}

async function precachedOrRuntime(event) {
  const shell = await caches.open(SHELL_CACHE);
  const precached = await shell.match(event.request, { ignoreSearch: true });
  if (precached) return precached;
  return staleWhileRevalidate(event);
}

async function staleWhileRevalidate(event) {
  const cache = await caches.open(RUNTIME_CACHE);
  const cached = await cache.match(event.request);
  const network = fetch(event.request).then(async (response) => {
    if (response.ok && response.type === 'basic') {
      await cache.put(event.request, response.clone());
      await trim(cache, RUNTIME_MAX_ENTRIES);
    }
    return response;
  });

  if (cached) {
    event.waitUntil(network.catch(() => {}));
    return cached;
  }
  return network;
}

/** Serves a byte range of a precached file (media elements ask for ranges). */
async function rangeFromCache(request) {
  const shell = await caches.open(SHELL_CACHE);
  const cached = await shell.match(request, { ignoreSearch: true });
  if (!cached) return fetch(request);
  const body = await cached.arrayBuffer();
  const size = body.byteLength;
  const match = /bytes=(\d*)-(\d*)/.exec(request.headers.get('range') || '');
  let start = 0;
  let end = size - 1;
  if (match && match[1]) {
    start = Number(match[1]);
    if (match[2]) end = Math.min(Number(match[2]), size - 1);
  } else if (match && match[2]) {
    start = Math.max(0, size - Number(match[2]));
  }
  if (start >= size) {
    return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
  }
  return new Response(body.slice(start, end + 1), {
    status: 206,
    headers: {
      'Content-Type': cached.headers.get('Content-Type') || 'application/octet-stream',
      'Content-Range': `bytes ${start}-${end}/${size}`,
      'Content-Length': String(end - start + 1),
      'Accept-Ranges': 'bytes',
    },
  });
}

/** Evicts the oldest entries (Cache keys are kept in insertion order). */
async function trim(cache, max) {
  const keys = await cache.keys();
  await Promise.all(keys.slice(0, Math.max(0, keys.length - max)).map((key) => cache.delete(key)));
}

/** Last resort: offline before the first install finished. */
function offlinePage() {
  const html = `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Offline · Solo Night Roulette</title>
<body style="margin:0;min-height:100dvh;display:grid;place-items:center;background:#f6f2ee;color:#2b2730;font:16px/1.5 system-ui;text-align:center;padding:24px">
<div><p style="font:500 12px system-ui;letter-spacing:.18em;text-transform:uppercase;color:#7d6646">Solo Night Roulette · Fête Studio Events</p>
<p style="font:italic 20px Georgia,serif">You're offline. Open the app once with a connection and it will work anywhere after that.</p></div>`;
  return new Response(html, { status: 503, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
}
