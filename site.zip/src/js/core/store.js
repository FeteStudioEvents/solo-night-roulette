/**
 * Tiny observable store persisted to localStorage.
 * State never leaves the device — no network, no accounts.
 */
export function createStore(key, initial) {
  let state = load(key, initial);
  const listeners = new Set();

  return {
    get: () => state,
    set(update) {
      const next = typeof update === 'function' ? update(state) : update;
      state = { ...state, ...next };
      persist(key, state);
      listeners.forEach((fn) => fn(state));
    },
    subscribe(fn) {
      listeners.add(fn);
      return () => listeners.delete(fn);
    },
    reset() {
      state = structuredClone(initial);
      persist(key, state);
      listeners.forEach((fn) => fn(state));
    },
  };
}

function load(key, initial) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? { ...initial, ...JSON.parse(saved) } : structuredClone(initial);
  } catch {
    return structuredClone(initial);
  }
}

function persist(key, state) {
  try {
    localStorage.setItem(key, JSON.stringify(state));
  } catch {
    // Storage full or blocked (private mode) — keep working in memory.
  }
}

/** App-wide store. Add fields here as features land; bump `version` on breaking shape changes. */
export const store = createStore('snr:solo-night', {
  version: 1,
  // Last choices on the pick screen.
  prefs: { mood: 'restorative', minutes: 60, budget: 0, energy: 'any' },
  // The plan being edited (see features/planner.js).
  plan: null,
  favourites: [],
  history: [],
  night: { status: 'idle' },
  ambient: { volume: 0.7, muted: false },
  ui: { welcomed: false, theme: 'auto' },
  // Where the user left off, written when the app is hidden or closed.
  session: { reflectionDraft: '' },
});
