/**
 * Minimal hash router. Hash routing keeps deep links working on any static
 * host and inside the service worker's single cached index.html.
 *
 * A route maps a path pattern (e.g. "/", "/entry/:id") to a lazy loader that
 * resolves to a view module: { title?, mount(root, ctx) => cleanup? }.
 */
export function createRouter({ root, routes, notFound, onNavigate }) {
  const compiled = Object.entries(routes).map(([pattern, load]) => ({
    load,
    keys: [...pattern.matchAll(/:(\w+)/g)].map((m) => m[1]),
    regex: new RegExp(`^${pattern.replace(/:\w+/g, '([^/]+)')}/?$`),
  }));

  let cleanup = null;
  let navId = 0;
  let started = false;

  function match(path) {
    for (const route of compiled) {
      const m = path.match(route.regex);
      if (m) {
        const params = Object.fromEntries(route.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
        return { load: route.load, params };
      }
    }
    return { load: notFound, params: {} };
  }

  async function resolve() {
    // In-page anchors such as the skip link (#view) are not routes.
    if (location.hash && !location.hash.startsWith('#/')) return;
    const id = ++navId;
    const path = location.hash.slice(1) || '/';
    const { load, params } = match(path);
    const view = await load();
    if (id !== navId) return; // a newer navigation won the race

    if (typeof cleanup === 'function') cleanup();
    root.replaceChildren();
    cleanup = await view.mount(root, { params, path, navigate });
    if (view.title) document.title = `${view.title} · Solo Night Roulette`;
    // After a navigation, move focus to the new screen's heading (announced by screen readers).
    // Not on first load: focus starts at the top of the page so the skip link comes first.
    const heading = root.querySelector('h1');
    const first = !started;
    started = true;
    if (first) {
      // leave focus where the browser put it
    } else if (heading) {
      heading.setAttribute('tabindex', '-1');
      heading.focus({ preventScroll: true });
    } else {
      root.focus({ preventScroll: true });
    }
    window.scrollTo(0, 0);
    onNavigate?.(path);
  }

  function navigate(path) {
    location.hash = path;
  }

  return {
    start() {
      window.addEventListener('hashchange', resolve);
      return resolve();
    },
    navigate,
  };
}
