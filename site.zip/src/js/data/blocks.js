/**
 * Solo Night Roulette — curated itinerary blocks.
 *
 * Every block is original copy written for Fête Studio Events.
 * House rules: no brand names, no specific films, songs, books or shows, no
 * alcohol (drinks are mocktails or tea), and no medical or therapy claims.
 *
 * Fields
 *   id        stable key (saved plans refer to it; never reuse or rename)
 *   title     short and aesthetic
 *   howTo     exactly two sentences
 *   category  moods it suits: 'restorative' | 'creative' | 'indulgent' (first = best fit)
 *   role      'open' (sets the scene) | 'main' | 'close' (wind down / reflect)
 *   minutes   length, a multiple of 5
 *   budget    0 = $0 (things most homes have), 1 = little treat, 2 = splurge
 *   energy    'low' | 'medium'
 *   sound     ambient pairing — an id from features/ambient.js: 'brown' | 'rain' | 'cabin'
 *   need      optional "you'll need" items
 *   group     optional: at most one block per group in a night ('meal', 'wash'),
 *             so a plan never has two dinners or two showers
 */

const R = 'restorative';
const C = 'creative';
const I = 'indulgent';

export const BLOCKS = [
  // ─── Openings: set the scene ──────────────────────────────────────────────
  {
    id: 'open-set-scene', role: 'open', title: 'Set the scene', category: [R, C, I],
    minutes: 5, budget: 0, energy: 'low', sound: 'cabin', need: ['A candle or one warm lamp'],
    howTo: 'Switch off the big light, turn on one warm lamp or a candle, and clear a single surface to be your spot for tonight. Put your phone on Do Not Disturb, set it face down, and let out one long breath.',
  },
  {
    id: 'open-intention', role: 'open', title: 'A one-word intention', category: [R, C],
    minutes: 5, budget: 0, energy: 'low', sound: 'rain', need: ['Paper and a pen'],
    howTo: 'Write a single word for how you would like to feel by the end of tonight: soft, proud, rested, playful. Fold the paper and keep it nearby, then open it again before bed.',
  },
  {
    id: 'open-room-reset', role: 'open', title: 'The ten-minute reset', category: [R, C],
    minutes: 10, budget: 0, energy: 'medium', sound: 'brown',
    howTo: 'Put away only what is in your line of sight: dishes to the sink, clothes to the basket, blankets folded. Open a window for a minute of fresh air, then close it and call the room ready.',
  },
  {
    id: 'open-change', role: 'open', title: 'Change into something soft', category: [R, I],
    minutes: 5, budget: 0, energy: 'low', sound: 'cabin', need: ['Your comfiest clothes'],
    howTo: 'Take off the day: work clothes, jewellery, anything with a waistband that argues back. Wash your face with warm water and put on the softest thing you own.',
  },
  {
    id: 'open-welcome-drink', role: 'open', title: 'Pour a welcome drink', category: [I, R],
    minutes: 5, budget: 1, energy: 'low', sound: 'cabin',
    need: ['Sparkling water', 'Citrus or fresh herbs', 'Your nicest glass'],
    howTo: 'Fill your nicest glass with ice, sparkling water and a squeeze of citrus, or a sprig of mint pressed between your fingers. A mocktail tastes better in a real glass, so leave the mug in the cupboard tonight.',
  },
  {
    id: 'open-studio', role: 'open', title: 'Open the studio', category: [C],
    minutes: 10, budget: 0, energy: 'medium', sound: 'rain', need: ['Whatever creative supplies you have'],
    howTo: 'Gather every creative supply you own onto one table: pens, paper, scissors, glue, paints, old magazines. Lay them out like a shop window so you can see everything at a glance.',
  },
  {
    id: 'open-tray', role: 'open', title: 'Lay a little tray', category: [I],
    minutes: 10, budget: 1, energy: 'low', sound: 'cabin', need: ['A tray or board', 'A small treat', 'A napkin'],
    howTo: 'Arrange a tray as if room service were bringing it: a folded napkin, a small treat, a glass of something cold, a candle if you have one. Carry it to wherever you will spend the evening.',
  },
  {
    id: 'open-scent', role: 'open', title: 'Scent the room', category: [R, I, C],
    minutes: 5, budget: 0, energy: 'low', sound: 'rain', need: ['A candle, citrus peel, or a scent you love'],
    howTo: 'Choose one scent for the night: a candle, a small pan of water simmering with citrus peel and cinnamon, or a light mist of perfume on a pillow. Let it be the signal that tonight is different.',
  },

  // ─── Restorative ─────────────────────────────────────────────────────────
  {
    id: 'long-soak', role: 'main', group: 'wash', title: 'Long soak, low light', category: [R, I],
    minutes: 30, budget: 0, energy: 'low', sound: 'rain', need: ['A bath or shower', 'A warm towel'],
    howTo: 'Run a bath as warm as you like, switch off the overhead light and leave the door open a crack for a little glow. If there is no tub, take a long, slow shower in the half-dark instead, then wrap up in the warmest towel you own.',
  },
  {
    id: 'legs-up', role: 'main', title: 'Legs up the wall', category: [R],
    minutes: 10, budget: 0, energy: 'low', sound: 'brown',
    howTo: 'Lie on the floor with your hips close to a wall and rest your legs up against it, arms loose at your sides. Stay as long as it feels comfortable and simply notice the ceiling, your breath and the quiet.',
  },
  {
    id: 'candle-breath', role: 'main', title: 'Breathing by candlelight', category: [R],
    minutes: 10, budget: 0, energy: 'low', sound: 'brown', need: ['A candle or lamp'],
    howTo: 'Sit comfortably and watch a candle flame or lamp glow while you breathe in for four counts, hold for four, out for four and hold for four. If your mind wanders, smile at it and begin the count again.',
  },
  {
    id: 'unsent-letter', role: 'main', title: 'A letter you won’t send', category: [R, C],
    minutes: 20, budget: 0, energy: 'low', sound: 'rain', need: ['Paper and a pen'],
    howTo: 'Write a letter to anyone, a friend, a younger you, a stranger you once met, saying everything you would never say out loud. When you are done, fold it away or tear it up; the writing was the point.',
  },
  {
    id: 'facial', role: 'main', title: 'At-home facial', category: [R, I],
    minutes: 20, budget: 1, energy: 'low', sound: 'rain', need: ['A face mask (or yogurt and honey)', 'A warm flannel'],
    howTo: 'Lean over a bowl of warm water with a towel draped over your head for a few minutes, then smooth on a mask and lie back while it sets. Rinse with a warm flannel and finish with your favourite moisturiser.',
  },
  {
    id: 'reading-nook', role: 'main', title: 'Build a reading nook', category: [R],
    minutes: 30, budget: 0, energy: 'low', sound: 'rain', need: ['Anything to read on paper', 'Cushions and blankets'],
    howTo: 'Pile every cushion and blanket you own into one corner and set a lamp at your shoulder. Read anything on paper for half an hour, and let yourself reread the good sentences.',
  },
  {
    id: 'sky-watch', role: 'main', title: 'Watch the sky', category: [R],
    minutes: 10, budget: 0, energy: 'low', sound: 'brown',
    howTo: 'Find a window, balcony or doorstep and simply watch the sky: clouds, the last of the light, a passing plane, the first star. Name three colours you can see before you come back in.',
  },
  {
    id: 'slow-loop', role: 'main', title: 'A slow loop outside', category: [R],
    minutes: 20, budget: 0, energy: 'medium', sound: 'brown', need: ['Comfortable shoes'],
    howTo: 'Keep your phone in your pocket on Do Not Disturb and take an unhurried walk around the block, noticing lit windows and the smell of the evening. A soft chime tells you when it is time to wander home.',
  },
  {
    id: 'floor-stretch', role: 'main', title: 'Floor stretch, slow and easy', category: [R],
    minutes: 15, budget: 0, energy: 'low', sound: 'brown', need: ['A mat, rug or towel'],
    howTo: 'Roll out a mat or towel and move through a handful of easy stretches, holding each for five slow breaths. Nothing needs to look impressive; follow whatever feels good tonight.',
  },
  {
    id: 'hand-foot', role: 'main', title: 'Hand and foot ritual', category: [R, I],
    minutes: 15, budget: 0, energy: 'low', sound: 'cabin', need: ['A lotion or oil you already own', 'Soft socks'],
    howTo: 'Warm a little lotion or oil between your palms and massage each hand, finger by finger, then each foot. Pull on a pair of soft socks afterwards to seal it in.',
  },
  {
    id: 'puzzle', role: 'main', title: 'Puzzle by lamplight', category: [R, C],
    minutes: 40, budget: 0, energy: 'low', sound: 'cabin', need: ['A jigsaw, or a printed crossword or word search'],
    howTo: 'Tip out a jigsaw, or print a crossword or word search, and settle in under a good lamp. Work the edges first, then the easy pieces, and stop wherever the time runs out.',
  },
  {
    id: 'tea-slowly', role: 'main', title: 'Tea, slowly', category: [R],
    minutes: 15, budget: 0, energy: 'low', sound: 'rain', need: ['A caffeine-free tea', 'A teapot or your favourite mug'],
    howTo: 'Brew a pot of caffeine-free tea and give it your full attention: the sound of the kettle, the colour as it steeps, the warmth of the cup. Drink it before it goes cold, with nothing else to do.',
  },
  {
    id: 'one-pot-supper', role: 'main', group: 'meal', title: 'A one-pot comfort supper', category: [R, I],
    minutes: 45, budget: 1, energy: 'medium', sound: 'cabin', need: ['Ingredients for a simple soup, stew or pasta'],
    howTo: 'Cook something simple and warming in a single pot, a soup, a stew or buttery pasta, tasting as you go. Eat it at the table from a proper bowl, with a napkin.',
  },
  {
    id: 'lie-down', role: 'main', title: 'Twenty minutes horizontal', category: [R],
    minutes: 20, budget: 0, energy: 'low', sound: 'brown', need: ['A blanket'],
    howTo: 'Lie down somewhere other than your bed, the sofa, a rug, a nest of cushions, with a blanket over you and no screens. You do not have to sleep; resting with your eyes closed counts.',
  },
  {
    id: 'fresh-sheets', role: 'main', title: 'Fresh-sheets ritual', category: [R],
    minutes: 15, budget: 0, energy: 'medium', sound: 'brown', need: ['Clean bedding'],
    howTo: 'Strip the bed and make it again with clean sheets, smoothing and tucking every corner. There is a particular joy in climbing into a freshly made bed later tonight.',
  },
  {
    id: 'tend-plants', role: 'main', title: 'Tend the plants', category: [R, C],
    minutes: 15, budget: 0, energy: 'medium', sound: 'rain', need: ['A watering can', 'A soft cloth'],
    howTo: 'Water every plant you own, wipe the dust from their leaves and turn them a little towards the light. Snip off anything brown and tell them they are doing well.',
  },
  {
    id: 'blanket-nest', role: 'main', title: 'Blanket nest', category: [R, I],
    minutes: 10, budget: 0, energy: 'low', sound: 'cabin', need: ['Every blanket in the house'],
    howTo: 'Build a nest on the sofa or the floor with every blanket and pillow you own, arranged exactly how you like it. Climb in and stay for ten unhurried minutes.',
  },

  // ─── Creative ────────────────────────────────────────────────────────────
  {
    id: 'collage', role: 'main', title: 'Magazine collage', category: [C],
    minutes: 30, budget: 0, energy: 'low', sound: 'rain', need: ['Old magazines or mail', 'Scissors and glue', 'A sheet of card'],
    howTo: 'Flip through old magazines, catalogues or junk mail and cut out any colour, word or shape that catches your eye. Arrange the pieces on card without a plan, and glue them down once it feels right.',
  },
  {
    id: 'sketch-table', role: 'main', title: 'Draw what’s on the table', category: [C],
    minutes: 20, budget: 0, energy: 'low', sound: 'cabin', need: ['A pencil and paper'],
    howTo: 'Set three ordinary objects in front of you, perhaps a mug, a lemon and your keys, and draw them in pencil. Look at the objects more than at the page; wobbly lines have more character.',
  },
  {
    id: 'watercolour', role: 'main', title: 'Wet-on-wet watercolour', category: [C],
    minutes: 30, budget: 1, energy: 'low', sound: 'rain', need: ['A small watercolour set', 'A brush', 'Thick paper', 'Two cups of water'],
    howTo: 'Wet the paper with clean water, then touch in colour and watch it bloom and bleed on its own. Try a sky at dusk, or simply let two colours meet and see what happens.',
  },
  {
    id: 'found-poem', role: 'main', title: 'A found poem', category: [C],
    minutes: 15, budget: 0, energy: 'low', sound: 'rain', need: ['A newspaper page, leaflet or receipt', 'A dark pen'],
    howTo: 'Take a page of printed text and circle words that sound good together, reading down the page. Black out everything else, and what is left is your poem.',
  },
  {
    id: 'small-bake', role: 'main', title: 'Small-batch bake', category: [C, I],
    minutes: 45, budget: 1, energy: 'medium', sound: 'cabin', need: ['Ingredients for a few cookies, a mug cake or scones'],
    howTo: 'Bake something in a small batch, four cookies, a mug cake or a couple of scones, just for you. Eat one warm from the tray, and do not save the best one for later.',
  },
  {
    id: 'zine', role: 'main', title: 'Fold a one-page zine', category: [C],
    minutes: 30, budget: 0, energy: 'low', sound: 'rain', need: ['One sheet of paper', 'Scissors', 'Pens'],
    howTo: 'Fold a single sheet into an eight-page booklet and fill each page about one tiny thing you love. Draw, write or collage; nobody else ever needs to see it.',
  },
  {
    id: 'colour-hunt', role: 'main', title: 'A colour hunt at home', category: [C],
    minutes: 20, budget: 0, energy: 'medium', sound: 'brown', need: ['Your phone camera'],
    howTo: 'Choose one colour and walk through your home taking ten close-up, oddly framed photos of things in that shade. Look at them side by side afterwards; it is like seeing your space for the first time.',
  },
  {
    id: 'pantry-remix', role: 'main', group: 'meal', title: 'Pantry remix', category: [C, I],
    minutes: 30, budget: 1, energy: 'medium', sound: 'cabin', need: ['Three cupboard staples', 'One fresh ingredient'],
    howTo: 'Pick three things from the cupboard and one fresh ingredient, and invent a dish with them, no recipe allowed. Plate it with care and give it a gloriously over-the-top menu name.',
  },
  {
    id: 'micro-story', role: 'main', title: 'A ten-line story', category: [C],
    minutes: 15, budget: 0, energy: 'low', sound: 'rain', need: ['Paper and a pen'],
    howTo: 'Write a complete story in exactly ten lines, with a beginning, a small problem and an ending. Start with the first sentence that arrives and do not cross anything out.',
  },
  {
    id: 'craft-kit', role: 'main', title: 'Open the craft kit', category: [C],
    minutes: 45, budget: 2, energy: 'low', sound: 'cabin', need: ['A beginner embroidery, candle-making or pottery-painting kit'],
    howTo: 'Unbox the craft kit you have been meaning to try and follow just the first few steps, slowly. Aim to enjoy the making rather than to finish.',
  },
  {
    id: 'mood-board', role: 'main', title: 'Mood board for next season', category: [C, R],
    minutes: 25, budget: 0, energy: 'low', sound: 'rain', need: ['Magazines or printed photos', 'Pins or tape'],
    howTo: 'Gather images, colours and words that feel like the season ahead and arrange them on a wall, a board or a notebook page. Keep it somewhere you will see it each morning.',
  },
  {
    id: 'flowers', role: 'main', title: 'Arrange grocery flowers', category: [C, I],
    minutes: 20, budget: 1, energy: 'low', sound: 'rain', need: ['A bunch of flowers or greenery', 'Scissors', 'Jars or a vase'],
    howTo: 'Strip the lower leaves, trim each stem at an angle and build the arrangement greenery first. Make two or three small posies rather than one big one, and put one beside your bed.',
  },
  {
    id: 'small-skill', role: 'main', title: 'Learn one small thing', category: [C],
    minutes: 30, budget: 0, energy: 'medium', sound: 'brown', need: ['Paper, string or a pen, depending on the skill'],
    howTo: 'Pick one small skill for tonight: folding a paper crane, tying a new knot, a calligraphy alphabet, shuffling cards like a dealer. Practise until you can do it once without looking at the instructions.',
  },
  {
    id: 'clay-dish', role: 'main', title: 'A little clay dish', category: [C],
    minutes: 40, budget: 1, energy: 'low', sound: 'cabin', need: ['Air-dry clay', 'A rolling pin or bottle', 'A small bowl to shape over'],
    howTo: 'Roll a ball of air-dry clay flat, press a pattern into it with a leaf or a fork, and drape it over an upturned bowl to make a trinket dish. Leave it to dry overnight and paint it another evening.',
  },
  {
    id: 'restyle-shelf', role: 'main', title: 'Restyle one shelf', category: [C, R],
    minutes: 20, budget: 0, energy: 'medium', sound: 'brown',
    howTo: 'Take everything off one shelf, dust it, and put back only what you love, grouped by colour or height. Add one unexpected object and step back to admire it.',
  },

  // ─── Indulgent ───────────────────────────────────────────────────────────
  {
    id: 'plated-dessert', role: 'main', title: 'Plate a dessert like a restaurant', category: [I],
    minutes: 15, budget: 1, energy: 'low', sound: 'cabin', need: ['A simple dessert', 'Fruit or cream', 'Your best plate'],
    howTo: 'Take a simple dessert and plate it like a pastry chef: a swoosh of sauce, a few berries, a dusting of something sweet. Sit down properly to eat it, with a small spoon.',
  },
  {
    id: 'snack-board', role: 'main', title: 'A snack board for one', category: [I],
    minutes: 20, budget: 1, energy: 'medium', sound: 'cabin', need: ['Cheese and crackers', 'Fruit', 'Something sweet'],
    howTo: 'Arrange a little board with the things you love most: cheese, crackers, fruit, olives, a square or two of chocolate. Fan everything out generously; it is a feast, not a snack.',
  },
  {
    id: 'good-takeout', role: 'main', group: 'meal', title: 'Order the good takeout', category: [I],
    minutes: 30, budget: 2, energy: 'low', sound: 'cabin', need: ['Your favourite local restaurant'],
    howTo: 'Order from the place you usually save for special occasions, and choose the dish you always look at but never pick. Plate it properly, light a candle and eat it slowly.',
  },
  {
    id: 'mocktail-lab', role: 'main', title: 'Mocktail lab', category: [I, C],
    minutes: 15, budget: 1, energy: 'medium', sound: 'rain', need: ['Juice and sparkling water', 'Herbs and citrus', 'Ice'],
    howTo: 'Line up juices, sparkling water, herbs and citrus and invent two alcohol-free mocktails, tasting as you go. Give the winner a name and write the recipe down for next time.',
  },
  {
    id: 'foot-soak', role: 'main', title: 'Foot soak and polish', category: [I, R],
    minutes: 25, budget: 0, energy: 'low', sound: 'rain', need: ['A basin', 'Warm water and a handful of salt', 'A towel'],
    howTo: 'Fill a basin with warm water and a handful of salt and soak your feet while you sit back under a blanket. Dry them well, smooth on lotion and paint your toes if you like.',
  },
  {
    id: 'hair-mask', role: 'main', title: 'Hair oil and a warm towel', category: [I, R],
    minutes: 20, budget: 1, energy: 'low', sound: 'rain', need: ['A hair oil or mask', 'A towel'],
    howTo: 'Work a hair oil or mask through the lengths of your hair, then wrap it in a towel warmed on a radiator or in the dryer. Lie back for twenty minutes before you rinse.',
  },
  {
    id: 'dress-up', role: 'main', title: 'Dress up for no one', category: [I, C],
    minutes: 15, budget: 0, energy: 'medium', sound: 'brown',
    howTo: 'Put on the outfit you save for best, do your hair, wear the good jewellery or the special scent. Keep it on for the rest of the evening, purely for yourself.',
  },
  {
    id: 'chocolate-tasting', role: 'main', title: 'A chocolate tasting', category: [I],
    minutes: 15, budget: 1, energy: 'low', sound: 'cabin', need: ['Three or four kinds of chocolate', 'A glass of water'],
    howTo: 'Break three or four different chocolates into squares and taste them from lightest to darkest, letting each one melt slowly. Jot down a word for each, like a connoisseur who takes it very seriously.',
  },
  {
    id: 'breakfast-dinner', role: 'main', group: 'meal', title: 'Breakfast for dinner', category: [I, R],
    minutes: 30, budget: 1, energy: 'medium', sound: 'cabin', need: ['Your favourite breakfast ingredients'],
    howTo: 'Cook your favourite breakfast, pancakes, eggs or toast with every topping, and eat it at night, at the table. Bonus points for fresh fruit and a cloth napkin.',
  },
  {
    id: 'steam-shower', role: 'main', group: 'wash', title: 'Steam-room shower', category: [I, R],
    minutes: 15, budget: 0, energy: 'low', sound: 'rain', need: ['A fresh towel', 'A body wash you love'],
    howTo: 'Run the shower hot with the door shut until the room fills with steam, with your favourite fragrant wash close at hand. Take your time, then step out into a warm towel.',
  },
  {
    id: 'candlelit-dinner', role: 'main', group: 'meal', title: 'Candlelit dinner for one', category: [I],
    minutes: 40, budget: 2, energy: 'medium', sound: 'cabin', need: ['Good ingredients', 'A candle', 'A cloth napkin'],
    howTo: 'Buy the good ingredients, perhaps ripe tomatoes, fresh bread and something special for the main, and cook a simple dinner you would serve a guest. Set the table, light the candle, and be the guest.',
  },
  {
    id: 'sugar-scrub', role: 'main', group: 'wash', title: 'Sugar scrub, made at home', category: [I, R],
    minutes: 20, budget: 0, energy: 'medium', sound: 'rain', need: ['Sugar', 'A little oil', 'A small jar'],
    howTo: 'Stir sugar with a little oil and a pinch of citrus zest in a jar, then use it in a warm shower. Your skin will feel lovely, and there will be some left for another night.',
  },
  {
    id: 'manicure', role: 'main', title: 'At-home manicure', category: [I],
    minutes: 25, budget: 0, energy: 'low', sound: 'rain', need: ['A nail polish you already own', 'A nail file'],
    howTo: 'Soak your hands in warm water, shape your nails and paint two careful coats of your favourite colour. Sit and let them dry with nothing to do but admire them.',
  },
  {
    id: 'dream-trip', role: 'main', title: 'Plan a dream trip', category: [I, C],
    minutes: 20, budget: 0, energy: 'low', sound: 'cabin', need: ['Paper, or a map if you have one'],
    howTo: 'Plan a trip you might never take: where you would stay, what you would eat, how each morning would begin. Write it out day by day in as much delicious detail as you like.',
  },
  {
    id: 'floor-picnic', role: 'main', group: 'meal', title: 'Living-room picnic', category: [I, R],
    minutes: 30, budget: 0, energy: 'low', sound: 'cabin', need: ['A blanket', 'A few things from the kitchen'],
    howTo: 'Spread a blanket on the living-room floor and lay out whatever is in the kitchen as a picnic: bread, fruit, cheese, leftovers. Eat it cross-legged with the lights low.',
  },
  {
    id: 'unbox', role: 'main', title: 'Unbox something lovely', category: [I],
    minutes: 10, budget: 2, energy: 'low', sound: 'rain', need: ['A small treat you bought for tonight'],
    howTo: 'Open the lovely thing you bought for yourself, new pyjamas, a beautiful notebook or a candle, as slowly as a present. Use it straight away.',
  },

  // ─── Closings: wind down / reflect ────────────────────────────────────────
  {
    id: 'close-three-lines', role: 'close', title: 'Three good lines', category: [R, C, I],
    minutes: 5, budget: 0, energy: 'low', sound: 'rain', need: ['Paper and a pen'],
    howTo: 'Write three short lines about tonight: one thing you enjoyed, one thing you noticed, and one thing you would happily do again. Keep the page in a drawer you will open next time.',
  },
  {
    id: 'close-slow-cup', role: 'close', title: 'A slow last cup', category: [R, I],
    minutes: 10, budget: 0, energy: 'low', sound: 'cabin', need: ['A caffeine-free tea or warm milk'],
    howTo: 'Make a caffeine-free tea or a mug of warm milk and drink it somewhere you can see out of a window. Leave the phone face down and let the cup be the only thing in your hands.',
  },
  {
    id: 'close-stretch', role: 'close', title: 'A gentle stretch to close', category: [R],
    minutes: 10, budget: 0, energy: 'low', sound: 'brown',
    howTo: 'Sit on the floor or the edge of the bed and move slowly through a few easy stretches: neck rolls, shoulder circles, a soft forward fold. Go only as far as feels good, and let each exhale be a little longer than the inhale.',
  },
  {
    id: 'close-gallery', role: 'close', title: 'A gallery of one', category: [C],
    minutes: 5, budget: 0, energy: 'low', sound: 'cabin',
    howTo: 'Lay out whatever you made tonight, finished or not, and give it a title and a date on a scrap of paper. Take one photo for yourself, then leave it out to greet you in the morning.',
  },
  {
    id: 'close-tomorrow', role: 'close', title: 'A gift for tomorrow', category: [R, C, I],
    minutes: 5, budget: 0, energy: 'low', sound: 'brown',
    howTo: 'Do one small kindness for tomorrow’s you: set out an outfit, fill a glass of water by the bed, or write the first task on a note. Then switch off every light but one.',
  },
  {
    id: 'close-candle-out', role: 'close', title: 'Candle-out', category: [I, R],
    minutes: 5, budget: 0, energy: 'low', sound: 'cabin',
    howTo: 'Sit with the candle or lamp you lit at the start and count ten slow breaths. On the last one, blow it out or switch it off, and let the room settle into the dark.',
  },
  {
    id: 'close-turn-down', role: 'close', title: 'Turn-down service', category: [I],
    minutes: 10, budget: 1, energy: 'low', sound: 'rain', need: ['A pillow mist or lotion', 'A small chocolate (optional)'],
    howTo: 'Make your bed the way a good hotel would: plump the pillows, fold the cover back in a neat triangle and mist the pillow lightly. Leave a small square of chocolate on it, then climb in as the guest.',
  },
  {
    id: 'close-read-back', role: 'close', title: 'Read back the night', category: [R, C, I],
    minutes: 5, budget: 0, energy: 'low', sound: 'rain',
    howTo: 'Look back over tonight’s plan and choose the moment you enjoyed most. Say one line out loud about why, even if it is only to the room.',
  },
];

/**
 * Flexible-length filler, used only as a last resort when a thin pool cannot fill
 * the chosen time exactly. Its length is set per plan item.
 */
export const FILLER = {
  id: 'free-time', role: 'main', title: 'Time that’s yours', category: [R, C, I],
  minutes: null, budget: 0, energy: 'low', sound: 'brown', flexible: true,
  howTo: 'Nothing is scheduled here, on purpose. Follow whatever you feel like doing, or simply sit back and enjoy the quiet.',
};

/** Always-available $0 anchors, used if a pool has no opening or closing that fits. */
export const DEFAULT_OPEN = 'open-set-scene';
export const DEFAULT_CLOSE = 'close-three-lines';

const INDEX = new Map([...BLOCKS, FILLER].map((block) => [block.id, block]));

/** Looks a block up by id. Unknown ids (e.g. from an older saved plan) resolve to the filler. */
export const byId = (id) => INDEX.get(id) ?? FILLER;
export const hasBlock = (id) => INDEX.has(id);
