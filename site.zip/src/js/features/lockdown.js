import { syncThemeColor } from './theme.js';

/**
 * Switches the whole app between idle, active, and complete night modes.
 * The `data-ritual` attribute drives the night palette and hides app chrome (see night.css).
 */
export function setRitualMode(mode) {
  const root = document.documentElement;
  if (mode === 'idle') delete root.dataset.ritual;
  else root.dataset.ritual = mode;
  syncThemeColor();
}

/**
 * Engages focus lockdown while a night is running:
 * - asks for confirmation before the tab is closed or reloaded
 * - reports how long the user was away whenever they come back to the app
 *
 * Returns a release function.
 */
export function engageLockdown({ onReturn } = {}) {
  let hiddenAt = null;
  const onVisibility = () => {
    if (document.hidden) {
      hiddenAt = Date.now();
    } else if (hiddenAt) {
      const away = Date.now() - hiddenAt;
      hiddenAt = null;
      onReturn?.(away);
    }
  };
  const onBeforeUnload = (event) => {
    event.preventDefault();
    event.returnValue = '';
  };

  document.addEventListener('visibilitychange', onVisibility);
  window.addEventListener('beforeunload', onBeforeUnload);

  return function release() {
    document.removeEventListener('visibilitychange', onVisibility);
    window.removeEventListener('beforeunload', onBeforeUnload);
  };
}
