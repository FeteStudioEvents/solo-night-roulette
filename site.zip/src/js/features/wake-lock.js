/**
 * Keeps the screen awake during a night.
 *
 * 1. Screen Wake Lock API (Chrome/Android, Safari 16.4+). The lock is dropped by the
 *    browser whenever the page is hidden, so it is re-requested on return.
 * 2. Fallback for older browsers: a tiny muted, looping inline video, which most
 *    mobile browsers treat as "media playing" and so do not dim the screen.
 * 3. If neither works, the night view shows a gentle hint to adjust auto-lock.
 *
 * Call keepAwake() from a tap (the video fallback needs a user gesture).
 */
let wanted = false;
let sentinel = null;
let video = null;
let mode = 'none';
const listeners = new Set();

const emit = () => listeners.forEach((fn) => fn(mode));
export const onWakeChange = (fn) => {
  listeners.add(fn);
  return () => listeners.delete(fn);
};
export const wakeMode = () => mode;

async function requestLock() {
  if (!('wakeLock' in navigator)) return false;
  try {
    sentinel = await navigator.wakeLock.request('screen');
    sentinel.addEventListener('release', () => {
      sentinel = null;
    });
    return true;
  } catch {
    return false;
  }
}

async function playVideo() {
  if (!video) {
    video = document.createElement('video');
    video.setAttribute('playsinline', '');
    video.setAttribute('muted', '');
    video.setAttribute('aria-hidden', 'true');
    video.muted = true;
    video.loop = true;
    video.preload = 'auto';
    // H.264 for Safari/iOS, VP8 WebM for browsers built without H.264.
    video.src = video.canPlayType('video/mp4; codecs="avc1.42E01E"') ? 'assets/media/keep-awake.mp4' : 'assets/media/keep-awake.webm';
    Object.assign(video.style, { position: 'fixed', width: '1px', height: '1px', opacity: '0.01', pointerEvents: 'none', bottom: '0', left: '0' });
    document.body.append(video);
  }
  try {
    await video.play();
    return true;
  } catch {
    return false;
  }
}

export async function keepAwake() {
  wanted = true;
  if (await requestLock()) mode = 'wakelock';
  else if (await playVideo()) mode = 'video';
  else mode = 'none';
  emit();
  return mode;
}

export function releaseAwake() {
  wanted = false;
  sentinel?.release().catch(() => {});
  sentinel = null;
  if (video) {
    video.pause();
    video.remove();
    video = null;
  }
  mode = 'none';
  emit();
}

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && wanted && !sentinel && mode === 'wakelock') requestLock();
});
