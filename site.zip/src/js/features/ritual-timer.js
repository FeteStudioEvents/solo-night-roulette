/**
 * Countdown engine (carried over from Digital Sunset, generalised).
 *
 * Time is always derived from an absolute end time rather than a running
 * counter, so a countdown stays accurate across reloads, sleep and app switches.
 * The caller supplies `remaining()`; this module only watches it.
 */

/** Calls onTick once per displayed second and onComplete once when time runs out. */
export function watchCountdown({ remaining, onTick, onComplete, interval = 250 }) {
  let lastSecond = null;
  let done = false;
  let id = null;

  const tick = () => {
    const ms = remaining();
    const second = Math.ceil(ms / 1000);
    if (second !== lastSecond) {
      lastSecond = second;
      onTick?.(ms);
    }
    if (ms <= 0 && !done) {
      done = true;
      clearInterval(id);
      onComplete?.();
    }
  };

  id = setInterval(tick, interval);
  tick();
  return () => clearInterval(id);
}

/** 754_000 → "12:34"; an hour or more → "1:02:03". */
export function formatClock(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const pad = (n) => String(n).padStart(2, '0');
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}

/** "8:05 PM" in the device's own locale and 12/24-hour preference. */
export const formatTime = (ms) => new Date(ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
