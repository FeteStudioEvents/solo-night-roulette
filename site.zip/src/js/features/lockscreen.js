import { byId } from '../data/blocks.js';
import { SOUND_LIST } from './ambient.js';
import { MOODS, planTitle, schedule } from './planner.js';
import { formatTime } from './ritual-timer.js';

/**
 * Lock-screen image of tonight's plan, drawn on a canvas at iPhone size (1170 × 2532).
 * System fonts only. The top ~30% is left calm so the phone's own clock sits over it.
 */
export const LOCK_W = 1170;
export const LOCK_H = 2532;
export const FILE_NAME = 'solo-night-lock-screen.png';

const SERIF = '"Iowan Old Style", "Palatino Linotype", Palatino, "Book Antiqua", Georgia, serif';
const SANS = 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';

const PALETTES = {
  dark: { top: '#141319', bottom: '#241f2c', glow: 'rgba(201, 173, 132, 0.13)', ink: '#ece6e1', muted: '#a59fa8', gold: '#c9ad84', moon: '#c7a3b1', line: 'rgba(236, 230, 225, 0.16)', star: 'rgba(255, 255, 255, 0.55)' },
  light: { top: '#f8f4f0', bottom: '#eee4dc', glow: 'rgba(184, 149, 90, 0.14)', ink: '#2b2730', muted: '#5f5866', gold: '#7d6646', moon: '#b4636e', line: 'rgba(43, 39, 48, 0.14)', star: 'rgba(125, 102, 70, 0.35)' },
};

/** Draws the plan onto `canvas` (resized to lock-screen dimensions) and returns it. */
export function drawLockScreen(canvas, plan, { start = Date.now(), theme = 'dark' } = {}) {
  const c = PALETTES[theme] ?? PALETTES.dark;
  canvas.width = LOCK_W;
  canvas.height = LOCK_H;
  const ctx = canvas.getContext('2d');
  const cx = LOCK_W / 2;

  // Paper
  const bg = ctx.createLinearGradient(0, 0, 0, LOCK_H);
  bg.addColorStop(0, c.top);
  bg.addColorStop(1, c.bottom);
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, LOCK_W, LOCK_H);
  const glow = ctx.createRadialGradient(cx, LOCK_H + 200, 100, cx, LOCK_H + 200, 1500);
  glow.addColorStop(0, c.glow);
  glow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, LOCK_W, LOCK_H);

  // A few stars, fixed positions so every export looks the same.
  ctx.fillStyle = c.star;
  [[150, 260, 3], [980, 330, 4], [860, 150, 2.5], [300, 520, 2.5], [1040, 600, 3], [90, 700, 2], [700, 470, 2]].forEach(([x, y, r]) => {
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  });

  // Crescent with a small dial
  drawGlyph(ctx, cx, 735, c);

  // Header
  ctx.textBaseline = 'alphabetic';
  ctx.fillStyle = c.gold;
  ctx.font = `600 32px ${SANS}`;
  trackedText(ctx, 'DO NOT DISTURB  ·  SOLO NIGHT', cx, 850, 0.22);

  ctx.fillStyle = c.ink;
  ctx.font = `italic 400 92px ${SERIF}`;
  const titleLines = wrap(ctx, planTitle(plan), 960);
  let y = 975;
  titleLines.forEach((line) => {
    ctx.textAlign = 'center';
    ctx.fillText(line, cx, y);
    y += 104;
  });

  const times = schedule(plan, start);
  const mood = MOODS.find((m) => m.id === plan.prefs.mood)?.label ?? '';
  ctx.fillStyle = c.muted;
  ctx.font = `400 38px ${SANS}`;
  ctx.textAlign = 'center';
  ctx.fillText(`${mood} · ${plan.prefs.minutes} min · ${formatTime(times[0].start)} – ${formatTime(times.at(-1).end)}`, cx, y - 20);

  ctx.strokeStyle = c.gold;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(cx - 70, y + 45);
  ctx.lineTo(cx + 70, y + 45);
  ctx.stroke();

  // Timeline
  const top = y + 120;
  const bottom = 2215;
  const n = plan.items.length;
  const rowH = Math.min(170, (bottom - top) / n);
  const k = Math.max(0.6, Math.min(1, rowH / 170));
  const listTop = top + Math.max(0, (bottom - top - rowH * n) * 0.35);
  const xTime = 150;
  const xDot = 372;
  const xText = 420;
  const maxText = LOCK_W - xText - 110;

  ctx.strokeStyle = c.line;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(xDot, listTop + rowH * 0.32);
  ctx.lineTo(xDot, listTop + rowH * (n - 1) + rowH * 0.32);
  ctx.stroke();

  plan.items.forEach((it, i) => {
    const block = byId(it.id);
    const rowY = listTop + rowH * i;
    const base = rowY + 58 * k;

    ctx.textAlign = 'left';
    ctx.fillStyle = c.gold;
    ctx.font = `500 ${Math.round(38 * k)}px ${SANS}`;
    ctx.fillText(formatTime(times[i].start), xTime, base);

    ctx.fillStyle = i === 0 || i === n - 1 ? c.gold : c.moon;
    ctx.beginPath();
    ctx.arc(xDot, base - 13 * k, 9 * k, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = c.ink;
    ctx.font = `400 ${Math.round(54 * k)}px ${SERIF}`;
    ctx.fillText(ellipsis(ctx, block.title, maxText), xText, base);

    const sound = SOUND_LIST.find((s) => s.id === block.sound)?.label;
    ctx.fillStyle = c.muted;
    ctx.font = `400 ${Math.round(31 * k)}px ${SANS}`;
    ctx.fillText(`${it.minutes} min${sound ? ` · ${sound}` : ''}`, xText, base + 48 * k);
  });

  // Brand
  ctx.textAlign = 'center';
  ctx.fillStyle = c.gold;
  ctx.font = `600 28px ${SANS}`;
  trackedText(ctx, 'SOLO NIGHT ROULETTE', cx, 2318, 0.24);
  ctx.fillStyle = c.muted;
  ctx.font = `italic 400 34px ${SERIF}`;
  ctx.fillText('by Fête Studio Events', cx, 2372);

  return canvas;
}

export function lockScreenBlob(plan, opts) {
  const canvas = drawLockScreen(document.createElement('canvas'), plan, opts);
  return new Promise((resolve, reject) => canvas.toBlob((blob) => (blob ? resolve(blob) : reject(new Error('Canvas export failed'))), 'image/png'));
}

/**
 * Shares the image with the Web Share API (saves straight to Photos on iPhone),
 * or downloads it where sharing files is not supported.
 * Returns 'shared' | 'downloaded' | 'cancelled'.
 */
export async function deliverLockScreen(blob) {
  const file = new File([blob], FILE_NAME, { type: 'image/png' });
  if (navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], title: 'Tonight · Solo Night Roulette' });
      return 'shared';
    } catch (err) {
      if (err?.name === 'AbortError') return 'cancelled';
      // NotAllowedError etc.: fall through to a download.
    }
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = FILE_NAME;
  a.rel = 'noopener';
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
  return 'downloaded';
}

// ─── Drawing helpers ───────────────────────────────────────────────────────

function drawGlyph(ctx, x, y, c) {
  ctx.save();
  // Crescent: a disc with a second disc cut out of it.
  ctx.save();
  ctx.beginPath();
  ctx.arc(x - 8, y, 46, 0, Math.PI * 2);
  ctx.clip();
  ctx.beginPath();
  ctx.rect(x - 60, y - 60, 120, 120);
  ctx.arc(x + 14, y - 16, 39, 0, Math.PI * 2);
  ctx.fillStyle = c.moon;
  ctx.fill('evenodd');
  ctx.restore();
  // Dial
  const dx = x + 30;
  const dy = y + 30;
  ctx.beginPath();
  ctx.arc(dx, dy, 20, 0, Math.PI * 2);
  ctx.fillStyle = c.top;
  ctx.fill();
  ctx.lineWidth = 4;
  ctx.strokeStyle = c.gold;
  ctx.stroke();
  ctx.lineWidth = 2.5;
  ctx.lineCap = 'round';
  for (let i = 0; i < 8; i++) {
    const a = (i * Math.PI) / 4;
    ctx.beginPath();
    ctx.moveTo(dx + Math.cos(a) * 6, dy + Math.sin(a) * 6);
    ctx.lineTo(dx + Math.cos(a) * 13, dy + Math.sin(a) * 13);
    ctx.stroke();
  }
  ctx.restore();
}

/** Letter-spaced text, centred on x. Drawn glyph by glyph so it works in every browser. */
function trackedText(ctx, text, x, y, em) {
  const size = parseFloat(/(\d+(?:\.\d+)?)px/.exec(ctx.font)[1]);
  const gap = size * em;
  const chars = [...text];
  const widths = chars.map((ch) => ctx.measureText(ch).width);
  const total = widths.reduce((s, w) => s + w, 0) + gap * (chars.length - 1);
  let at = x - total / 2;
  ctx.textAlign = 'left';
  chars.forEach((ch, i) => {
    ctx.fillText(ch, at, y);
    at += widths[i] + gap;
  });
  ctx.textAlign = 'center';
}

/** One line if it fits, otherwise two balanced lines (no lonely last word). */
function wrap(ctx, text, width) {
  if (ctx.measureText(text).width <= width) return [text];
  const words = text.split(' ');
  let best = null;
  for (let i = 1; i < words.length; i++) {
    const lines = [words.slice(0, i).join(' '), words.slice(i).join(' ')];
    const widest = Math.max(...lines.map((l) => ctx.measureText(l).width));
    if (!best || widest < best.widest) best = { lines, widest };
  }
  return best ? best.lines : [text];
}

function ellipsis(ctx, text, width) {
  if (ctx.measureText(text).width <= width) return text;
  let out = text;
  while (out.length > 1 && ctx.measureText(`${out}…`).width > width) out = out.slice(0, -1);
  return `${out.trimEnd()}…`;
}
