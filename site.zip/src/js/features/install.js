/**
 * "Add to Home Screen" helpers. Installed (standalone / fullscreen) launches hide every hint.
 */
let deferredPrompt = null;
const listeners = new Set();

window.addEventListener('beforeinstallprompt', (event) => {
  // Keep Chrome's own mini-infobar quiet; the welcome card offers an Install button instead.
  event.preventDefault();
  deferredPrompt = event;
  listeners.forEach((fn) => fn(true));
});
window.addEventListener('appinstalled', () => {
  deferredPrompt = null;
  listeners.forEach((fn) => fn(false));
});

export function isStandalone() {
  if (navigator.standalone === true) return true; // iOS home-screen launch
  return ['standalone', 'fullscreen', 'minimal-ui'].some((m) => matchMedia(`(display-mode: ${m})`).matches);
}

export function platform() {
  const ua = navigator.userAgent;
  const iOS = /iPhone|iPad|iPod/.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  if (iOS) return 'ios';
  if (/Android/.test(ua)) return 'android';
  return 'other';
}

export function installHint() {
  switch (platform()) {
    case 'ios':
      return 'On iPhone or iPad: open this page in Safari, tap Share, then “Add to Home Screen”.';
    case 'android':
      return 'On Android: in Chrome, tap Install, or open the ⋮ menu and choose “Install app”.';
    default:
      return 'On your phone: in Safari tap Share → “Add to Home Screen”; in Chrome tap Install. On a computer, use the install icon in the address bar.';
  }
}

export const canPrompt = () => Boolean(deferredPrompt);
export const onPromptChange = (fn) => {
  listeners.add(fn);
  return () => listeners.delete(fn);
};

export async function promptInstall() {
  if (!deferredPrompt) return false;
  const event = deferredPrompt;
  deferredPrompt = null;
  event.prompt();
  const { outcome } = await event.userChoice;
  return outcome === 'accepted';
}
