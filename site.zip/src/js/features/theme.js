import { store } from '../core/store.js';

/**
 * Appearance: 'auto' follows the device, 'light' / 'dark' force a palette.
 * A night in progress always uses the night palette (see lockdown.js).
 * index.html applies a saved forced theme before first paint to avoid a flash.
 */
const PAPER = '#f6f2ee';
const NIGHT = '#16151b';

export function applyTheme(theme = store.get().ui.theme) {
  const root = document.documentElement;
  if (theme === 'light' || theme === 'dark') root.dataset.theme = theme;
  else delete root.dataset.theme;
  syncThemeColor();
}

export function setTheme(theme) {
  store.set(({ ui }) => ({ ui: { ...ui, theme } }));
  applyTheme(theme);
}

/** True when the night palette is showing. */
export function isDark() {
  const root = document.documentElement;
  if (root.dataset.ritual || root.dataset.theme === 'dark') return true;
  if (root.dataset.theme === 'light') return false;
  return matchMedia('(prefers-color-scheme: dark)').matches;
}

/** Keeps the browser / status-bar colour in step with the visible palette. */
export function syncThemeColor() {
  const root = document.documentElement;
  const forced = root.dataset.ritual ? NIGHT : root.dataset.theme === 'dark' ? NIGHT : root.dataset.theme === 'light' ? PAPER : null;
  for (const meta of document.querySelectorAll('meta[name="theme-color"]')) {
    meta.dataset.default ??= meta.content;
    meta.content = forced ?? meta.dataset.default;
  }
}
