import { store } from '../core/store.js';
import { snapshot } from './planner.js';

/**
 * The night's state machine, persisted in the store with absolute times so it
 * survives reloads, a locked phone and app switches.
 *
 *   idle → active ⇄ paused → complete → idle
 *
 * night: { status, plan, index, blockEndsAt, pausedLeft, startedAt, endedAt, endedEarly, historyId }
 */
const MINUTE = 60_000;
const HISTORY_MAX = 30;

export const IDLE = { status: 'idle' };

export const getNight = () => store.get().night ?? IDLE;
const setNight = (night) => store.set({ night });

export function startNight(plan, now = Date.now()) {
  const frozen = { ...plan, items: plan.items.map((it) => ({ ...it })) };
  setNight({
    status: 'active',
    plan: frozen,
    index: 0,
    startedAt: now,
    blockEndsAt: now + frozen.items[0].minutes * MINUTE,
    pausedLeft: null,
    endedAt: null,
    endedEarly: false,
    historyId: null,
  });
}

/** Milliseconds left in the current block. */
export function blockLeft(night = getNight(), now = Date.now()) {
  if (night.status === 'paused') return night.pausedLeft;
  if (night.status === 'active') return Math.max(0, night.blockEndsAt - now);
  return 0;
}

/** Milliseconds left in the whole night. */
export function nightLeft(night = getNight(), now = Date.now()) {
  if (night.status !== 'active' && night.status !== 'paused') return 0;
  const later = night.plan.items.slice(night.index + 1).reduce((s, it) => s + it.minutes * MINUTE, 0);
  return blockLeft(night, now) + later;
}

/**
 * Advances past every block whose time is up (several, if the phone slept through them).
 * Returns { advanced, completed }.
 */
export function syncNight(now = Date.now()) {
  let night = getNight();
  if (night.status !== 'active') return { advanced: 0, completed: false };
  let advanced = 0;
  while (now >= night.blockEndsAt) {
    if (night.index >= night.plan.items.length - 1) {
      finish({ ...night }, night.blockEndsAt, false);
      return { advanced, completed: true };
    }
    const index = night.index + 1;
    night = { ...night, index, blockEndsAt: night.blockEndsAt + night.plan.items[index].minutes * MINUTE };
    advanced++;
  }
  if (advanced) setNight(night);
  return { advanced, completed: false };
}

export function pauseNight(now = Date.now()) {
  const night = getNight();
  if (night.status !== 'active') return;
  setNight({ ...night, status: 'paused', pausedLeft: Math.max(0, night.blockEndsAt - now) });
}

export function resumeNight(now = Date.now()) {
  const night = getNight();
  if (night.status !== 'paused') return;
  setNight({ ...night, status: 'active', blockEndsAt: now + night.pausedLeft, pausedLeft: null });
}

/** Skips to the next block now. Returns true if the night just completed. */
export function skipBlock(now = Date.now()) {
  const night = getNight();
  if (night.status !== 'active' && night.status !== 'paused') return false;
  if (night.index >= night.plan.items.length - 1) {
    finish(night, now, false);
    return true;
  }
  const index = night.index + 1;
  setNight({ ...night, status: 'active', index, pausedLeft: null, blockEndsAt: now + night.plan.items[index].minutes * MINUTE });
  return false;
}

export function endNight(now = Date.now()) {
  const night = getNight();
  if (night.status !== 'active' && night.status !== 'paused') return;
  finish(night, now, true);
}

function finish(night, at, endedEarly) {
  const historyId = `h${at.toString(36)}`;
  const minutesDone = Math.round((at - night.startedAt) / MINUTE);
  const entry = {
    id: historyId,
    at: night.startedAt,
    endedAt: at,
    completed: !endedEarly,
    minutesDone: endedEarly ? minutesDone : night.plan.prefs.minutes,
    reflection: '',
    ...snapshot(night.plan),
  };
  store.set(({ history }) => ({
    history: [entry, ...history.filter((h) => h.id !== historyId)].slice(0, HISTORY_MAX),
    night: { ...night, status: 'complete', endedAt: at, endedEarly, pausedLeft: null, historyId },
  }));
}

export function saveReflection(text) {
  const { historyId } = getNight();
  if (!historyId) return;
  store.set(({ history }) => ({
    history: history.map((h) => (h.id === historyId ? { ...h, reflection: text.trim().slice(0, 160) } : h)),
  }));
}

export function clearNight() {
  setNight(IDLE);
}
