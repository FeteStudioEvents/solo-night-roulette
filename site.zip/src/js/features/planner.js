import { BLOCKS, FILLER, DEFAULT_OPEN, DEFAULT_CLOSE, byId } from '../data/blocks.js';

/**
 * The night generator and plan editing rules. Pure functions, no DOM: every
 * function takes a plan and returns a new one, so views can re-render freely
 * and tests can import this module directly.
 *
 * A plan:  { id, createdAt, prefs, items: [{ key, id, minutes, locked }], relaxed }
 *   items[0] is always an opening block and the last item is always a closing block.
 *   The item minutes always add up to prefs.minutes.
 *
 * Filters
 *   budget  never relaxed: a block's budget must be ≤ the chosen budget.
 *   energy  'low' keeps only low-energy blocks; 'medium' allows both and favours medium;
 *           'any' allows both.
 *   mood    a block must list the chosen mood in its category.
 * When the pool is too thin to fill the time exactly, the generator relaxes energy first,
 * then mood, and only as a last resort adds a flexible "Time that's yours" block.
 */

export const MOODS = [
  { id: 'restorative', label: 'Restorative', note: 'Slow, soft, replenishing' },
  { id: 'creative', label: 'Creative', note: 'Make something just for you' },
  { id: 'indulgent', label: 'Indulgent', note: 'A little luxury, no reason needed' },
];
export const DURATIONS = [30, 60, 90, 120];
export const BUDGETS = [
  { id: 0, label: '$0', note: 'Use what you have' },
  { id: 1, label: 'Little treat', note: 'A small spend' },
  { id: 2, label: 'Splurge', note: 'Go on' },
];
export const ENERGIES = [
  { id: 'any', label: 'Either' },
  { id: 'low', label: 'Low' },
  { id: 'medium', label: 'Medium' },
];

export const DEFAULT_PREFS = { mood: 'restorative', minutes: 60, budget: 0, energy: 'any' };

const TIERS = [
  { name: null, mood: true, energy: true },
  { name: 'energy', mood: true, energy: false },
  { name: 'mood', mood: false, energy: true },
  { name: 'wide', mood: false, energy: false },
];

const MAX_STEPS = 25_000;

// ─── Small helpers ─────────────────────────────────────────────────────────

/** Seeded PRNG for repeatable tests (mulberry32). */
export function seededRandom(seed = 1) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

let keySeq = 0;
const newKey = () => `k${Date.now().toString(36)}${(keySeq++).toString(36)}${Math.random().toString(36).slice(2, 6)}`;
const newId = () => `n${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;

const item = (block, minutes = block.minutes) => ({ key: newKey(), id: block.id, minutes, locked: false });

export const normalisePrefs = (prefs = {}) => ({
  mood: MOODS.some((m) => m.id === prefs.mood) ? prefs.mood : DEFAULT_PREFS.mood,
  minutes: DURATIONS.includes(Number(prefs.minutes)) ? Number(prefs.minutes) : DEFAULT_PREFS.minutes,
  budget: [0, 1, 2].includes(Number(prefs.budget)) ? Number(prefs.budget) : DEFAULT_PREFS.budget,
  energy: ENERGIES.some((e) => e.id === prefs.energy) ? prefs.energy : DEFAULT_PREFS.energy,
});

function fits(block, prefs, tier) {
  if (block.budget > prefs.budget) return false;
  if (tier.mood && !block.category.includes(prefs.mood)) return false;
  if (tier.energy && prefs.energy === 'low' && block.energy !== 'low') return false;
  return true;
}

function weight(block, prefs) {
  let w = 1;
  if (block.category.includes(prefs.mood)) w *= 4;
  if (block.category[0] === prefs.mood) w *= 1.5;
  if (prefs.energy === 'medium' && block.energy === 'medium') w *= 2;
  if (prefs.energy === 'any' && block.energy === 'low') w *= 1.2;
  // A treat or splurge night should feel like one: spending blocks are favoured.
  if (prefs.budget > 0 && block.budget > 0) w *= 3;
  if (prefs.budget > 0 && block.budget === prefs.budget) w *= 2;
  return w;
}

/** Weighted random order (Efraimidis–Spirakis): heavier blocks tend to come first. */
function weightedShuffle(list, prefs, rng) {
  return list
    .map((block) => ({ block, k: rng() ** (1 / weight(block, prefs)) }))
    .sort((a, b) => b.k - a.k)
    .map(({ block }) => block);
}

/** Groups already present among these block ids (a night has at most one 'meal', one 'wash'). */
const groupsOf = (ids) => new Set([...ids].map((id) => byId(id).group).filter(Boolean));

function candidates(pool, role, prefs, tier, exclude, groupIds = exclude) {
  const taken = groupsOf(groupIds);
  return pool.filter((b) => b.role === role && !b.flexible && !exclude.has(b.id) && !(b.group && taken.has(b.group)) && fits(b, prefs, tier));
}

/** Finds distinct blocks whose minutes add up to exactly `target`. Randomised depth-first search. */
function fillExact(cands, target, prefs, rng, maxCount) {
  if (target === 0) return [];
  const order = weightedShuffle(cands, prefs, rng);
  const picked = [];
  let steps = 0;
  const groups = new Set();
  const dfs = (start, remaining) => {
    if (remaining === 0) return true;
    if (picked.length >= maxCount || ++steps > MAX_STEPS) return false;
    for (let i = start; i < order.length; i++) {
      const b = order[i];
      if (b.minutes > remaining || (b.group && groups.has(b.group))) continue;
      picked.push(b);
      if (b.group) groups.add(b.group);
      if (dfs(i + 1, remaining - b.minutes)) return true;
      picked.pop();
      if (b.group) groups.delete(b.group);
    }
    return false;
  };
  return dfs(0, target) ? picked : null;
}

/** The night winds down: livelier blocks come first, quieter ones later. Stable otherwise. */
const windDown = (blocks) => [...blocks].sort((a, b) => (b.energy === 'medium') - (a.energy === 'medium'));

const maxMains = (minutes) => Math.max(2, Math.ceil(minutes / 15));

export const planMinutes = (plan) => plan.items.reduce((sum, it) => sum + it.minutes, 0);

export function roleAt(plan, index) {
  if (index === 0) return 'open';
  if (index === plan.items.length - 1) return 'close';
  return 'main';
}

// ─── Generate ──────────────────────────────────────────────────────────────

/**
 * Builds a plan that fills prefs.minutes exactly: opening → mains → closing.
 * opts.locked: { open?, close?, mains?: [{ item, pos }] } items to keep (used by respin).
 */
export function generatePlan(rawPrefs, { pool = BLOCKS, rng = Math.random, locked = {} } = {}) {
  const prefs = normalisePrefs(rawPrefs);
  const lockedMains = locked.mains ?? [];
  const lockedIds = new Set([locked.open?.id, locked.close?.id, ...lockedMains.map((m) => m.item.id)].filter(Boolean));
  const lockedMinutes = lockedMains.reduce((s, m) => s + m.item.minutes, 0);

  for (const tier of TIERS) {
    const opens = locked.open ? [locked.open] : weightedShuffle(candidates(pool, 'open', prefs, tier, lockedIds), prefs, rng).slice(0, 4).map((b) => item(b));
    const closes = locked.close ? [locked.close] : weightedShuffle(candidates(pool, 'close', prefs, tier, lockedIds), prefs, rng).slice(0, 4).map((b) => item(b));
    for (const open of opens) {
      for (const close of closes) {
        if (open.id === close.id) continue;
        const remaining = prefs.minutes - open.minutes - close.minutes - lockedMinutes;
        if (remaining < 0) continue;
        const exclude = new Set([...lockedIds, open.id, close.id]);
        const mains = fillExact(candidates(pool, 'main', prefs, tier, exclude), remaining, prefs, rng, Math.max(1, maxMains(prefs.minutes) - lockedMains.length));
        if (mains) return compose(prefs, open, windDown(mains).map((b) => item(b)), lockedMains, close, tier.name);
      }
    }
  }
  return fallbackPlan(prefs, pool, rng, locked);
}

/** Last resort for a thin pool: fit what we can, then hand the remainder back as free time. */
function fallbackPlan(prefs, pool, rng, locked) {
  const lockedMains = locked.mains ?? [];
  const wide = TIERS[TIERS.length - 1];
  const lockedIds = new Set([locked.open?.id, locked.close?.id, ...lockedMains.map((m) => m.item.id)].filter(Boolean));
  const pickEnd = (role, fallbackId) => {
    const found = weightedShuffle(candidates(pool, role, prefs, wide, lockedIds), prefs, rng)[0] ?? byId(fallbackId);
    return item(found);
  };
  const open = locked.open ?? pickEnd('open', DEFAULT_OPEN);
  let close = locked.close ?? pickEnd('close', DEFAULT_CLOSE);
  if (close.id === open.id) close = item(byId(DEFAULT_CLOSE));

  let remaining = prefs.minutes - open.minutes - close.minutes - lockedMains.reduce((s, m) => s + m.item.minutes, 0);
  const used = new Set([...lockedIds, open.id, close.id]);
  const mains = [];
  const groups = groupsOf(used);
  for (const b of weightedShuffle(candidates(pool, 'main', prefs, wide, used), prefs, rng)) {
    if ((b.minutes <= remaining - 5 || b.minutes === remaining) && !(b.group && groups.has(b.group))) {
      mains.push(item(b));
      if (b.group) groups.add(b.group);
      remaining -= b.minutes;
    }
    if (remaining === 0) break;
  }
  if (remaining > 0) mains.push(item(FILLER, remaining));
  return compose(prefs, open, mains, lockedMains, close, 'filler');
}

/** Merges new mains with locked mains, which keep their original slot where possible. */
function compose(prefs, open, mains, lockedMains, close, relaxed) {
  const count = mains.length + lockedMains.length;
  const slots = new Array(count).fill(null);
  for (const { item: it, pos } of [...lockedMains].sort((a, b) => a.pos - b.pos)) {
    let p = Math.min(pos, count - 1);
    while (slots[p]) p = (p + 1) % count;
    slots[p] = it;
  }
  const queue = [...mains];
  for (let i = 0; i < count; i++) if (!slots[i]) slots[i] = queue.shift();
  return { id: newId(), createdAt: Date.now(), prefs, items: [open, ...slots, close], relaxed };
}

// ─── Edit ──────────────────────────────────────────────────────────────────

/** Re-spins every unlocked block. Locked blocks stay, in the same slot. */
export function respin(plan, { pool = BLOCKS, rng = Math.random } = {}) {
  const { items } = plan;
  const last = items.length - 1;
  const locked = {
    open: items[0].locked ? items[0] : null,
    close: items[last].locked ? items[last] : null,
    mains: items.slice(1, last).map((it, pos) => ({ item: it, pos })).filter(({ item: it }) => it.locked),
  };
  const next = generatePlan(plan.prefs, { pool, rng, locked });
  return { ...next, id: plan.id, favId: plan.favId };
}

export function toggleLock(plan, index) {
  const items = plan.items.map((it, i) => (i === index ? { ...it, locked: !it.locked } : it));
  return { ...plan, items };
}

/** Moves a middle block. Openings and closings are anchored to the ends. */
export function canMove(plan, from, to) {
  const last = plan.items.length - 1;
  return from !== to && from > 0 && from < last && to > 0 && to < last;
}

export function moveItem(plan, from, to) {
  if (!canMove(plan, from, to)) return plan;
  const items = [...plan.items];
  const [moved] = items.splice(from, 1);
  items.splice(to, 0, moved);
  return { ...plan, items };
}

/**
 * Replaces one unlocked block, keeping the plan's total time:
 *   1. a different block of the same length;
 *   2. (middle blocks) two blocks that add up to the same length;
 *   3. a block of another length, rebalanced by swapping one other unlocked
 *      middle block for one whose length absorbs the difference.
 * Each strategy is tried with the strict filters before any are relaxed.
 * Returns { plan, changed: [keys], mode } or null if nothing else fits.
 */
export function rerollItem(plan, index, { pool = BLOCKS, rng = Math.random } = {}) {
  const target = plan.items[index];
  if (!target || target.locked) return null;
  const role = roleAt(plan, index);
  const { prefs } = plan;
  const used = new Set(plan.items.map((it) => it.id));
  // The slot being replaced does not count towards the meal / wash limit.
  const others = (...skip) => new Set(plan.items.filter((_, j) => !skip.includes(j)).map((it) => it.id));
  const replace = (items, at, ...withItems) => [...items.slice(0, at), ...withItems, ...items.slice(at + 1)];
  const done = (items, changed, mode) => ({ plan: { ...plan, items }, changed, mode });

  for (const tier of TIERS) {
    const options = weightedShuffle(candidates(pool, role, prefs, tier, used, others(index)), prefs, rng);

    // 1. Same length.
    const same = options.find((b) => b.minutes === target.minutes);
    if (same) {
      const fresh = item(same);
      return done(replace(plan.items, index, fresh), [fresh.key], 'same');
    }

    // 2. Two blocks that add up to the slot.
    if (role === 'main') {
      const pair = fillExact(options, target.minutes, prefs, rng, 2);
      if (pair && pair.length === 2) {
        const fresh = windDown(pair).map((b) => item(b));
        return done(replace(plan.items, index, ...fresh), fresh.map((f) => f.key), 'split');
      }
    }

    // 3. Another length, rebalanced against one other unlocked middle block.
    const partners = plan.items
      .map((it, i) => ({ it, i }))
      .filter(({ it, i }) => i !== index && i > 0 && i < plan.items.length - 1 && !it.locked);
    for (const cand of options) {
      const delta = cand.minutes - target.minutes;
      for (const { it, i } of partners) {
        if (cand.group && cand.group === byId(it.id).group) continue;
        const need = it.minutes - delta;
        if (need <= 0) continue;
        const partner = it.id === FILLER.id
          ? FILLER
          : weightedShuffle(candidates(pool, 'main', prefs, tier, new Set([...used, cand.id]), new Set([...others(index, i), cand.id])), prefs, rng).find((b) => b.minutes === need);
        if (!partner) continue;
        const fresh = item(cand);
        const swapped = partner === FILLER ? { ...it, minutes: need } : item(partner);
        const items = plan.items.map((x, j) => (j === index ? fresh : j === i ? swapped : x));
        return done(items, [fresh.key, swapped.key], 'rebalance');
      }
    }
  }

  return null;
}

// ─── Read helpers for views ────────────────────────────────────────────────

/** Start time for each item, given when the night begins. */
export function schedule(plan, start) {
  let t = new Date(start).getTime();
  return plan.items.map((it) => {
    const at = t;
    t += it.minutes * 60_000;
    return { start: at, end: t };
  });
}

/** Next clean 5-minute mark from now: the default "if you start now" time. */
export function nextStart(now = Date.now()) {
  const step = 5 * 60_000;
  return Math.ceil(now / step) * step;
}

const TITLES = {
  restorative: ['A soft, slow night in', 'An evening to refill', 'Quiet hours, just for you'],
  creative: ['A night for making things', 'An evening in the studio', 'Small makes, big joy'],
  indulgent: ['A little luxury, just for you', 'An evening of small pleasures', 'Treat yourself tonight'],
};

export function planTitle(plan) {
  const options = TITLES[plan.prefs.mood] ?? TITLES.restorative;
  const seed = [...plan.id].reduce((s, ch) => s + ch.charCodeAt(0), 0);
  return options[seed % options.length];
}

export function planMeta(prefs) {
  const mood = MOODS.find((m) => m.id === prefs.mood)?.label ?? '';
  const budget = BUDGETS.find((b) => b.id === prefs.budget)?.label ?? '';
  const energy = prefs.energy === 'any' ? '' : ` · ${ENERGIES.find((e) => e.id === prefs.energy).label} energy`;
  return `${mood} · ${prefs.minutes} min · ${budget}${energy}`;
}

/** Copy of a saved plan with fresh keys, ready to edit or replay. */
export function clonePlan(saved) {
  return {
    id: newId(),
    createdAt: Date.now(),
    prefs: normalisePrefs(saved.prefs),
    items: saved.items.map((it) => ({ key: newKey(), id: it.id, minutes: it.minutes, locked: false })),
    relaxed: null,
  };
}

/** Plain, storable copy (no keys or lock state). */
export const snapshot = (plan) => ({ prefs: plan.prefs, items: plan.items.map(({ id, minutes }) => ({ id, minutes })) });
