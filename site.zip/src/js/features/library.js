import { store } from '../core/store.js';
import { planTitle, snapshot } from './planner.js';

/** Favourite plans, saved on this device. */
const FAV_MAX = 40;

export const favourites = () => store.get().favourites;
export const history = () => store.get().history;
export const isFavourite = (plan) => Boolean(plan?.favId && favourites().some((f) => f.id === plan.favId));

/** Saves a plan as a favourite and returns the plan tagged with its favourite id. */
export function saveFavourite(plan, name = planTitle(plan)) {
  const id = `f${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
  store.set(({ favourites: list }) => ({
    favourites: [{ id, name, savedAt: Date.now(), ...snapshot(plan) }, ...list].slice(0, FAV_MAX),
  }));
  return { ...plan, favId: id };
}

export function removeFavourite(id) {
  store.set(({ favourites: list }) => ({ favourites: list.filter((f) => f.id !== id) }));
}

export function clearHistory() {
  store.set({ history: [] });
}
