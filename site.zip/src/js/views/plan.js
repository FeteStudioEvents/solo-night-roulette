import { clock } from '../core/clock.js';
import { announce, html, on, qs, qsa, render } from '../core/dom.js';
import { store } from '../core/store.js';
import { toast } from '../core/toast.js';
import { byId } from '../data/blocks.js';
import * as ambient from '../features/ambient.js';
import { isFavourite, removeFavourite, saveFavourite } from '../features/library.js';
import { deliverLockScreen, lockScreenBlob } from '../features/lockscreen.js';
import { getNight, startNight } from '../features/night-runner.js';
import {
  BUDGETS, canMove, moveItem, nextStart, planMeta, planMinutes, planTitle,
  rerollItem, respin, roleAt, schedule, toggleLock,
} from '../features/planner.js';
import { formatTime } from '../features/ritual-timer.js';
import { isDark } from '../features/theme.js';
import { keepAwake } from '../features/wake-lock.js';
import { icon } from './icons.js';

export const title = 'Your night';

const RELAXED = {
  energy: 'To fill your time exactly, one or two livelier moments slipped in.',
  mood: 'We borrowed a moment from a neighbouring mood so your night fits exactly.',
  wide: 'We widened the pool a little so your night fits exactly.',
  filler: 'Part of tonight is left unscheduled, on purpose. That time is yours.',
};

const soundLabel = (id) => ambient.SOUND_LIST.find((s) => s.id === id)?.label ?? '';

function moment(plan, it, i, times) {
  const block = byId(it.id);
  const role = roleAt(plan, i);
  const last = plan.items.length - 1;
  const label = role === 'open' ? 'Opening' : role === 'close' ? 'Closing' : `Moment ${i}`;
  const budget = BUDGETS.find((b) => b.id === block.budget);
  const t = block.title;
  return html`
    <li class="moment ${it.locked ? 'is-locked' : ''}" data-key="${it.key}" data-role="${role}" data-index="${i}">
      <div class="moment__rail" aria-hidden="true"><span class="moment__dot"></span></div>
      <article class="moment__card" aria-labelledby="t-${it.key}">
        <div class="moment__top">
          <p class="moment__when"><time>${formatTime(times[i].start)}</time> · <span>${label}</span></p>
          <span class="chip">${it.minutes} min</span>
        </div>
        <h2 class="moment__title" id="t-${it.key}">${t}</h2>
        <p class="moment__how">${block.howTo}</p>
        ${block.need?.length ? html`<p class="moment__need"><span class="moment__need-label">You’ll need</span> ${block.need.join(' · ')}</p>` : ''}
        <p class="moment__tags">
          <span class="tag">${icon(block.sound, 'icon icon--tag')} ${soundLabel(block.sound)}</span>
          ${block.budget > 0 ? html`<span class="tag">${budget.label}</span>` : html`<span class="tag">$0</span>`}
          ${block.energy === 'medium' ? html`<span class="tag">Livelier</span>` : ''}
        </p>
        <div class="moment__tools">
          <button class="icon-btn" type="button" data-action="lock" aria-pressed="${it.locked}"
                  aria-label="${it.locked ? `Unlock ${t}` : `Lock ${t}`}" title="${it.locked ? 'Unlock' : 'Lock'}">
            ${icon(it.locked ? 'lock' : 'unlock', 'icon')}
          </button>
          <button class="icon-btn" type="button" data-action="reroll" ${it.locked ? 'disabled' : ''}
                  aria-label="Reroll ${t}" title="Reroll">${icon('dice', 'icon')}</button>
          ${role === 'main' ? html`
            <button class="icon-btn" type="button" data-action="up" ${canMove(plan, i, i - 1) ? '' : 'disabled'}
                    aria-label="Move ${t} earlier" title="Move earlier">${icon('up', 'icon')}</button>
            <button class="icon-btn" type="button" data-action="down" ${canMove(plan, i, i + 1) ? '' : 'disabled'}
                    aria-label="Move ${t} later" title="Move later">${icon('down', 'icon')}</button>
            <span class="drag-handle" data-drag aria-hidden="true" title="Drag to reorder">${icon('grip', 'icon')}</span>
          ` : html`<span class="moment__anchor">${i === 0 ? 'Always first' : i === last ? 'Always last' : ''}</span>`}
        </div>
      </article>
    </li>`;
}

const summary = (plan, times) =>
  `${plan.items.length} moments · ${planMinutes(plan)} min · ${formatTime(times[0].start)} – ${formatTime(times.at(-1).end)} if you start soon`;

function template(plan, favourite) {
  const start = nextStart();
  const times = schedule(plan, start);
  return html`
    <div class="plan ${plan.fresh ? 'is-fresh' : ''}" data-el="plan">
      <header class="plan__head">
        <p class="eyebrow">${planMeta(plan.prefs)}</p>
        <h1>${planTitle(plan)}</h1>
        <p class="text-muted" data-el="summary">${summary(plan, times)}</p>
        ${plan.relaxed ? html`<p class="notice text-sm">${RELAXED[plan.relaxed]}</p>` : ''}
      </header>

      <ol class="timeline" data-el="list" aria-label="Tonight’s plan">
        ${plan.items.map((it, i) => moment(plan, it, i, times))}
      </ol>

      <div class="plan__actions">
        <button class="btn btn--lux btn--block" type="button" data-action="start">${icon('moon', 'icon')} Start the night</button>
        <div class="grid-2">
          <button class="btn btn--ghost" type="button" data-action="respin">${icon('spin', 'icon')} Re-spin unlocked</button>
          <button class="btn btn--ghost" type="button" data-action="favourite" aria-pressed="${favourite}">
            ${icon(favourite ? 'check' : 'heart', 'icon')} ${favourite ? 'Saved' : 'Save'}
          </button>
          <button class="btn btn--ghost" type="button" data-action="export">${icon('image', 'icon')} Lock-screen image</button>
          <a class="btn btn--ghost" href="#/">Change choices</a>
        </div>
        <p class="text-xs text-muted center">Lock a moment to keep it, then re-spin the rest.</p>
      </div>
    </div>`;
}

export function mount(root, { navigate }) {
  if (!store.get().plan) {
    navigate('/');
    return undefined;
  }
  const night = getNight();
  if (night.status === 'active' || night.status === 'paused') {
    navigate('/night');
    return undefined;
  }

  const getPlan = () => store.get().plan;
  const offs = [];
  let preparedAt = null;
  let prepared = null;
  let prepareTimer = null;

  const paint = (focus) => {
    render(root, template(getPlan(), isFavourite(getPlan())));
    if (focus) restoreFocus(focus);
    schedulePrepare();
  };

  const restoreFocus = ({ key, action }) => {
    const item = qs(`[data-key="${key}"]`, root);
    const target = (action && qs(`[data-key="${key}"] [data-action="${action}"]`, root)) || null;
    const fallback = item && qsa('[data-action]', item).find((b) => !b.disabled);
    const el = target && !target.disabled ? target : fallback ?? qs(`[data-action="${action}"]`, root);
    el?.focus({ preventScroll: false });
  };

  const update = (plan, focus, { keepFavourite = false } = {}) => {
    // An edited plan is a new plan; the saved favourite stays exactly as it was saved.
    store.set({ plan: { ...plan, favId: keepFavourite ? plan.favId : null, fresh: false } });
    paint(focus);
  };

  // Lock-screen image: prepared in the background so Share runs straight from the tap.
  const exportOptions = () => ({ start: nextStart(), theme: isDark() ? 'dark' : 'light' });
  const signature = () => JSON.stringify([getPlan().items.map((it) => [it.id, it.minutes]), exportOptions()]);
  function schedulePrepare() {
    clearTimeout(prepareTimer);
    prepareTimer = setTimeout(async () => {
      const sig = signature();
      try {
        const blob = await lockScreenBlob(getPlan(), exportOptions());
        prepared = blob;
        preparedAt = sig;
      } catch {
        prepared = null;
      }
    }, 600);
  }

  const itemAt = (btn) => {
    const li = btn.closest('.moment');
    return { key: li.dataset.key, index: Number(li.dataset.index) };
  };

  const actions = {
    lock(btn) {
      const { key, index } = itemAt(btn);
      const plan = toggleLock(getPlan(), index);
      update(plan, { key, action: 'lock' }, { keepFavourite: true });
      const it = plan.items[index];
      announce(`${byId(it.id).title} ${it.locked ? 'locked' : 'unlocked'}.`);
    },
    reroll(btn) {
      const { index } = itemAt(btn);
      const result = rerollItem(getPlan(), index);
      if (!result) {
        toast('That’s the only fit for this slot tonight. Unlock another moment or re-spin.');
        return;
      }
      update(result.plan, { key: result.changed[0], action: 'reroll' });
      result.changed.forEach((key) => qs(`[data-key="${key}"]`, root)?.classList.add('is-new'));
      const names = result.changed.map((key) => byId(result.plan.items.find((x) => x.key === key).id).title);
      const note = result.mode === 'rebalance' ? ' Another moment was adjusted to keep your total time.' : '';
      announce(`New: ${names.join(' and ')}.${note}`);
    },
    up: (btn) => move(btn, -1),
    down: (btn) => move(btn, 1),
    respin() {
      const plan = getPlan();
      if (plan.items.every((it) => it.locked)) {
        toast('Everything is locked. Unlock a moment to re-spin it.');
        return;
      }
      update(respin(plan), null);
      qsa('.moment:not(.is-locked)', root).forEach((li) => li.classList.add('is-new'));
      qs('[data-action="respin"]', root)?.focus();
      announce('Re-spun. Locked moments stayed put.');
    },
    favourite() {
      const plan = getPlan();
      if (isFavourite(plan)) {
        removeFavourite(plan.favId);
        store.set({ plan: { ...plan, favId: null } });
        announce('Removed from My nights.');
      } else {
        store.set({ plan: saveFavourite(plan) });
        toast('Saved to My nights.');
      }
      paint({ action: 'favourite' });
    },
    async export(btn) {
      btn.disabled = true;
      try {
        const blob = preparedAt === signature() && prepared ? prepared : await lockScreenBlob(getPlan(), exportOptions());
        const result = await deliverLockScreen(blob);
        if (result === 'shared') toast('Shared. Set it as your lock screen from Photos.');
        if (result === 'downloaded') toast('Image saved. Set it as your lock screen from your photos or downloads.');
      } catch {
        toast('Sorry, the image could not be made on this device.');
      } finally {
        btn.disabled = false;
        btn.focus();
      }
    },
    start() {
      const plan = getPlan();
      startNight(plan);
      // Audio and the wake lock both need this tap, so they start here, before navigating.
      if (!store.get().ambient.muted) {
        ambient.setVolume(store.get().ambient.volume);
        ambient.crossfadeTo(byId(plan.items[0].id).sound, 2);
      }
      keepAwake();
      navigate('/night');
    },
  };

  function move(btn, dir) {
    const { key, index } = itemAt(btn);
    const plan = getPlan();
    if (!canMove(plan, index, index + dir)) return;
    update(moveItem(plan, index, index + dir), { key, action: dir < 0 ? 'up' : 'down' });
    const pos = index + dir;
    announce(`${byId(plan.items[index].id).title} moved to position ${pos + 1} of ${plan.items.length}.`);
  }

  offs.push(on(root, 'click', '[data-action]', (event, btn) => {
    if (btn.disabled) return;
    actions[btn.dataset.action]?.(btn, event);
  }));

  // Drag to reorder (pointer: mouse, touch, pen). Keyboard users have the up/down buttons.
  let drag = null;
  const onDown = (event) => {
    const handle = event.target.closest('[data-drag]');
    if (!handle || event.button !== 0) return;
    const li = handle.closest('.moment');
    event.preventDefault();
    handle.setPointerCapture?.(event.pointerId);
    drag = { li, handle, from: Number(li.dataset.index), startY: event.clientY, lastY: event.clientY, startScroll: scrollY, origin: li.offsetTop, raf: 0 };
    li.classList.add('is-dragging');
    drag.raf = requestAnimationFrame(autoScroll);
  };
  // Near the top or bottom edge, the page scrolls so a block can travel the whole list.
  const EDGE = 72;
  function autoScroll() {
    if (!drag) return;
    const y = drag.lastY;
    const step = y > innerHeight - EDGE ? 10 : y < EDGE + 40 ? -10 : 0;
    if (step) {
      const before = scrollY;
      scrollBy(0, step);
      if (scrollY !== before) position(drag.lastY);
    }
    drag.raf = requestAnimationFrame(autoScroll);
  }
  const onMove = (event) => {
    if (!drag) return;
    drag.lastY = event.clientY;
    position(event.clientY);
  };
  function position(clientY) {
    const { li } = drag;
    const dy = clientY - drag.startY + (scrollY - drag.startScroll);
    const visualTop = drag.origin + dy;
    // Swap as soon as the finger crosses a neighbour's midpoint, however tall the cards are.
    const mid = (el) => {
      const box = el.getBoundingClientRect();
      return box.top + box.height / 2;
    };
    const prev = li.previousElementSibling;
    const next = li.nextElementSibling;
    if (next?.dataset.role === 'main' && clientY > mid(next)) {
      next.after(li);
    } else if (prev?.dataset.role === 'main' && clientY < mid(prev)) {
      prev.before(li);
    }
    li.style.transform = `translateY(${visualTop - li.offsetTop}px)`;
  }
  const onUp = () => {
    if (!drag) return;
    const { li, from } = drag;
    cancelAnimationFrame(drag.raf);
    drag = null;
    li.classList.remove('is-dragging');
    li.style.transform = '';
    const to = [...li.parentElement.children].indexOf(li);
    const plan = getPlan();
    if (to !== from && canMove(plan, from, to)) {
      const key = li.dataset.key;
      update(moveItem(plan, from, to), null);
      qs(`[data-key="${key}"]`, root)?.classList.add('is-new');
      announce(`${byId(plan.items[from].id).title} moved to position ${to + 1} of ${plan.items.length}.`);
    } else {
      paint(null);
    }
  };
  root.addEventListener('pointerdown', onDown);
  root.addEventListener('pointermove', onMove);
  root.addEventListener('pointerup', onUp);
  root.addEventListener('pointercancel', onUp);

  // Keep the "if you start soon" times honest as the evening goes on.
  offs.push(clock.onMinute(() => {
    if (drag) return;
    const plan = getPlan();
    const times = schedule(plan, nextStart());
    qsa('.moment time', root).forEach((el, i) => { el.textContent = formatTime(times[i].start); });
    qs('[data-el="summary"]', root).textContent = summary(plan, times);
  }));

  paint(null);
  if (getPlan().fresh) {
    store.set({ plan: { ...getPlan(), fresh: false } });
    announce(`Your night is ready: ${getPlan().items.length} moments, ${planMinutes(getPlan())} minutes.`);
  }

  return () => {
    clearTimeout(prepareTimer);
    offs.forEach((off) => off());
    root.removeEventListener('pointerdown', onDown);
    root.removeEventListener('pointermove', onMove);
    root.removeEventListener('pointerup', onUp);
    root.removeEventListener('pointercancel', onUp);
  };
}
