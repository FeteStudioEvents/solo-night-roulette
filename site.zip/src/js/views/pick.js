import { announce, html, on, prefersReducedMotion, qs, raw, render } from '../core/dom.js';
import { store } from '../core/store.js';
import { canPrompt, installHint, isStandalone, onPromptChange, promptInstall } from '../features/install.js';
import { getNight } from '../features/night-runner.js';
import { BUDGETS, DURATIONS, ENERGIES, MOODS, generatePlan, normalisePrefs } from '../features/planner.js';
import { icon } from './icons.js';

export const title = 'Pick your night';

const SPIN_MS = 1500;

function choice(group, value, checked, face) {
  return html`
    <label class="choice choice--${group}">
      <input class="choice__input" type="radio" name="${group}" value="${value}" ${checked ? 'checked' : ''}>
      <span class="choice__face">${face}</span>
    </label>`;
}

function welcome({ welcomed }) {
  if (welcomed) return '';
  const standalone = isStandalone();
  return html`
    <section class="welcome card card--soft fade-in" aria-labelledby="welcome-title" data-el="welcome">
      <p class="eyebrow" id="welcome-title">Welcome</p>
      <ul class="welcome__lines serif">
        <li>Tell us how you’d like tonight to feel, and how long you have.</li>
        <li>Spin, and the whole evening is planned to the minute.</li>
        <li>Press start: time, sound and calm are taken care of.</li>
      </ul>
      ${standalone ? '' : html`
        <p class="welcome__hint text-sm" data-el="install-hint">
          ${icon('moon', 'icon icon--inline')}
          <span>Best kept on your Home Screen. ${installHint()}</span>
        </p>`}
      <p class="welcome__legal text-sm" data-el="license-agree">By continuing, you agree to the <a class="legal-link" href="LICENSE.txt" target="_blank" rel="noopener">personal-use license</a>.</p>
      <div class="row welcome__actions">
        <button class="btn btn--ghost" type="button" data-action="install" data-el="install-btn" hidden>Install</button>
        <button class="btn" type="button" data-action="welcomed">Got it</button>
      </div>
    </section>`;
}

function template(state) {
  const prefs = normalisePrefs(state.prefs);
  const night = getNight();
  const inProgress = night.status === 'active' || night.status === 'paused';
  return html`
    <div class="pick">
      ${welcome(state.ui)}

      ${inProgress ? html`
        <a class="resume card" href="#/night">
          <span class="eyebrow">Night in progress</span>
          <span class="serif text-lg">Return to your night</span>
        </a>` : ''}

      <header class="pick__head">
        <p class="eyebrow">Tonight, just you</p>
        <h1>Plan a night in, <em>beautifully</em>.</h1>
        <p class="text-muted pick__lede">Four quick choices, one spin, and your evening is planned.</p>
      </header>

      <form class="pick__form" data-el="form" novalidate>
        <fieldset class="field">
          <legend class="field__label">How should it feel?</legend>
          <div class="mood-grid">
            ${MOODS.map((m) => choice('mood', m.id, prefs.mood === m.id, html`
              ${icon(m.id, 'icon choice__icon')}
              <span class="choice__title">${m.label}</span>
              <span class="choice__note">${m.note}</span>`))}
          </div>
        </fieldset>

        <fieldset class="field">
          <legend class="field__label">How long do you have?</legend>
          <div class="seg seg--4">
            ${DURATIONS.map((d) => choice('minutes', d, prefs.minutes === d, html`<span class="seg__big">${d}</span><span class="seg__small">min</span>`))}
          </div>
        </fieldset>

        <fieldset class="field">
          <legend class="field__label">Budget</legend>
          <div class="seg seg--3">
            ${BUDGETS.map((b) => choice('budget', b.id, prefs.budget === b.id, html`<span class="seg__title">${b.label}</span>`))}
          </div>
        </fieldset>

        <fieldset class="field">
          <legend class="field__label">Energy <span class="field__opt">optional</span></legend>
          <div class="seg seg--3">
            ${ENERGIES.map((e) => choice('energy', e.id, prefs.energy === e.id, html`<span class="seg__title">${e.label}</span>`))}
          </div>
        </fieldset>

        <button class="btn btn--lux btn--block spin-btn" type="submit" data-el="spin">
          ${icon('spin', 'icon')} Spin the night
        </button>
        ${state.plan ? html`<p class="center"><a class="link-btn" href="#/plan">Back to your last plan</a></p>` : ''}
      </form>

      <div class="spin-stage" data-el="stage" hidden>
        <div class="spin-stage__inner" role="status" aria-live="polite">
          ${dial()}
          <p class="serif text-lg">Spinning your night…</p>
        </div>
      </div>
    </div>`;
}

/** The roulette dial: twelve soft segments in the brand palette around a crescent. */
function dial() {
  const colours = ['var(--c-blush)', 'var(--c-sage)', 'var(--c-sky)', 'var(--c-champagne)'];
  const segs = Array.from({ length: 12 }, (_, i) => {
    const a0 = (i * 30 - 90) * (Math.PI / 180);
    const a1 = ((i + 1) * 30 - 90) * (Math.PI / 180);
    const p = (r, a) => `${(100 + r * Math.cos(a)).toFixed(2)} ${(100 + r * Math.sin(a)).toFixed(2)}`;
    return `<path d="M${p(52, a0)} L${p(92, a0)} A92 92 0 0 1 ${p(92, a1)} L${p(52, a1)} A52 52 0 0 0 ${p(52, a0)}Z" fill="${colours[i % 4]}"/>`;
  }).join('');
  return html`
    <svg class="dial" viewBox="0 0 200 200" aria-hidden="true" focusable="false">
      <g class="dial__wheel" data-el="wheel">${raw(segs)}
        <circle cx="100" cy="100" r="92" fill="none" stroke="var(--c-gold)" stroke-width="2"/>
        <circle cx="100" cy="100" r="52" fill="var(--c-surface)" stroke="var(--c-gold)" stroke-width="2"/>
      </g>
      <path d="M100 18 92 4h16z" fill="var(--c-gold)"/>
      <path d="M113 84a22 22 0 1 0 6 28 17 17 0 1 1-6-28z" fill="var(--c-accent)"/>
    </svg>`;
}

export function mount(root, { navigate }) {
  render(root, template(store.get()));
  const form = qs('[data-el="form"]', root);
  let spinTimer = null;
  const offs = [];

  const readPrefs = () => {
    const data = new FormData(form);
    return normalisePrefs({
      mood: data.get('mood'),
      minutes: data.get('minutes'),
      budget: data.get('budget'),
      energy: data.get('energy'),
    });
  };

  // Remember the last choices as soon as they change.
  form.addEventListener('change', () => store.set({ prefs: readPrefs() }));

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    if (spinTimer) return;
    const prefs = readPrefs();
    store.set({ prefs, plan: { ...generatePlan(prefs), fresh: true } });
    if (prefersReducedMotion()) {
      navigate('/plan');
      return;
    }
    const stage = qs('[data-el="stage"]', root);
    const wheel = qs('[data-el="wheel"]', root);
    stage.hidden = false;
    wheel.style.setProperty('--turn', `${1080 + Math.floor(Math.random() * 360)}deg`);
    requestAnimationFrame(() => stage.classList.add('is-spinning'));
    announce('Spinning your night.');
    spinTimer = setTimeout(() => navigate('/plan'), SPIN_MS);
  });

  // Welcome card
  offs.push(on(root, 'click', '[data-action="welcomed"]', () => {
    store.set(({ ui }) => ({ ui: { ...ui, welcomed: true } }));
    qs('[data-el="welcome"]', root)?.remove();
    qs('h1', root)?.focus();
  }));
  const installBtn = qs('[data-el="install-btn"]', root);
  const syncInstall = (available) => {
    if (installBtn) installBtn.hidden = !available || isStandalone();
  };
  syncInstall(canPrompt());
  offs.push(onPromptChange(syncInstall));
  offs.push(on(root, 'click', '[data-action="install"]', async () => {
    if (await promptInstall()) announce('Installed. You’ll find Solo Night on your home screen.');
    syncInstall(canPrompt());
  }));

  return () => {
    clearTimeout(spinTimer);
    offs.forEach((off) => off());
  };
}
