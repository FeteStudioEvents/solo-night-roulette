import { html, raw } from '../core/dom.js';

/** Line icons on a 24px grid. Stroke colour follows currentColor. */
const svg = (body, cls = 'icon') => html`<svg viewBox="0 0 24 24" class="${cls}" aria-hidden="true" focusable="false">${raw(body)}</svg>`;

export const ICON = {
  // Ambient sounds (same shapes as Digital Sunset)
  brown: (cls) => svg('<path d="M3 9c3-3 6 3 9 0s6-3 9 0M3 15c3-3 6 3 9 0s6-3 9 0"/>', cls),
  rain: (cls) => svg('<path d="M7 4.5 5.5 9M12.5 3 11 7.5M18 4.5 16.5 9M9.5 12 8 16.5M15 12l-1.5 4.5M12 18.5 11 21"/>', cls),
  cabin: (cls) => svg('<path d="M3 11 11 4l8 7M5 9.5V20h12V9.5M9.5 20v-5h3v5M19.5 20 21 17l-1.5-4L18 17z"/>', cls),
  // Moods
  restorative: (cls) => svg('<path d="M12 20c-5-2-7-6-7-11 4 0 7 2 7 6 0-4 3-6 7-6 0 5-2 9-7 11z"/><path d="M12 20v-5"/>', cls),
  creative: (cls) => svg('<path d="M4 20c2.5 0 4-1.5 4-3.5a2.5 2.5 0 0 0-5 0c0 1-.5 2.5-1 3.5h2z"/><path d="M8.5 14.5 19 4a1.4 1.4 0 0 1 2 2L10.5 16.5"/>', cls),
  indulgent: (cls) => svg('<path d="M11 3.5c.6 4.2 2.8 6.4 7 7-4.2.6-6.4 2.8-7 7-.6-4.2-2.8-6.4-7-7 4.2-.6 6.4-2.8 7-7z"/><path d="M18.5 15c.2 1.5 1 2.3 2.5 2.5-1.5.2-2.3 1-2.5 2.5-.2-1.5-1-2.3-2.5-2.5 1.5-.2 2.3-1 2.5-2.5z"/>', cls),
  // Actions
  lock: (cls) => svg('<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>', cls),
  unlock: (cls) => svg('<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.6-1.8"/>', cls),
  dice: (cls) => svg('<rect x="4" y="4" width="16" height="16" rx="3.5"/><circle cx="9" cy="9" r=".9" fill="currentColor"/><circle cx="15" cy="15" r=".9" fill="currentColor"/><circle cx="15" cy="9" r=".9" fill="currentColor"/><circle cx="9" cy="15" r=".9" fill="currentColor"/>', cls),
  up: (cls) => svg('<path d="m6 14 6-6 6 6"/>', cls),
  down: (cls) => svg('<path d="m6 10 6 6 6-6"/>', cls),
  grip: (cls) => svg('<circle cx="9" cy="6" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="6" r="1.2" fill="currentColor" stroke="none"/><circle cx="9" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="9" cy="18" r="1.2" fill="currentColor" stroke="none"/><circle cx="15" cy="18" r="1.2" fill="currentColor" stroke="none"/>', cls),
  heart: (cls) => svg('<path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/>', cls),
  image: (cls) => svg('<rect x="6" y="2.5" width="12" height="19" rx="2.5"/><path d="M9.5 6h5M9.5 10h5M9.5 14h3"/>', cls),
  spin: (cls) => svg('<path d="M20 12a8 8 0 1 1-2.3-5.6"/><path d="M20 4v4h-4"/>', cls),
  play: (cls) => svg('<path d="M8 5.5v13l10.5-6.5z"/>', cls),
  pause: (cls) => svg('<path d="M8.5 5.5v13M15.5 5.5v13"/>', cls),
  next: (cls) => svg('<path d="M6 5.5v13l9-6.5zM18 5.5v13"/>', cls),
  stop: (cls) => svg('<rect x="6.5" y="6.5" width="11" height="11" rx="2"/>', cls),
  mute: (cls) => svg('<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="m16 9.5 5 5M21 9.5l-5 5"/>', cls),
  volume: (cls) => svg('<path d="M4 9.5h3.5L12 6v12l-4.5-3.5H4z"/><path d="M15.5 9.5a3.5 3.5 0 0 1 0 5M18 7a7 7 0 0 1 0 10"/>', cls),
  moon: (cls) => svg('<path d="M19 14.5A7.5 7.5 0 1 1 9.5 5a6 6 0 0 0 9.5 9.5z"/>', cls),
  info: (cls) => svg('<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.6v.1"/>', cls),
  close: (cls) => svg('<path d="m6.5 6.5 11 11M17.5 6.5l-11 11"/>', cls),
  check: (cls) => svg('<path d="m5 12.5 4.5 4.5L19 7.5"/>', cls),
};

export const icon = (name, cls) => ICON[name]?.(cls) ?? '';
