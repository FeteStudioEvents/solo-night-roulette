import { html, render } from '../core/dom.js';

export const title = 'Not found';

export function mount(root) {
  render(root, html`
    <section class="center stack fade-in mt-6">
      <h1>Lost the way?</h1>
      <p class="text-muted">This page wandered off for a quiet night of its own.</p>
      <a class="btn" href="#/">Plan a night</a>
    </section>
  `);
}
