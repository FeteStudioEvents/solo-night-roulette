import { announce, html, on, qs, render } from '../core/dom.js';
import { onSuspend } from '../core/session.js';
import { store } from '../core/store.js';
import { toast } from '../core/toast.js';
import { byId } from '../data/blocks.js';
import * as ambient from '../features/ambient.js';
import { saveFavourite } from '../features/library.js';
import { engageLockdown, setRitualMode } from '../features/lockdown.js';
import {
  blockLeft, clearNight, endNight, getNight, nightLeft, pauseNight, resumeNight,
  saveReflection, skipBlock, syncNight,
} from '../features/night-runner.js';
import { planTitle, roleAt } from '../features/planner.js';
import { formatClock, formatTime, watchCountdown } from '../features/ritual-timer.js';
import { keepAwake, onWakeChange, releaseAwake, wakeMode } from '../features/wake-lock.js';
import { icon } from './icons.js';

export const title = 'Night mode';

const RING = 2 * Math.PI * 46;
const CONFIRM_MS = 4000;

const currentSound = (night) => night.manualSound ?? byId(night.plan.items[night.index].id).sound;

function wakeText(mode) {
  if (mode === 'none') return 'Your screen may dim tonight. If it does, set Auto-Lock to Never in Settings for the evening.';
  return 'Your screen will stay awake while the night runs.';
}

function runningTemplate(night, { muted }) {
  const { plan, index } = night;
  const it = plan.items[index];
  const block = byId(it.id);
  const total = plan.items.length;
  const next = plan.items[index + 1];
  const role = roleAt(plan, index);
  const sound = currentSound(night);
  const paused = night.status === 'paused';
  return html`
    <div class="night" data-state="${night.status}" data-el="night">
      <p class="eyebrow night__step">
        <span>Moment ${index + 1} of ${total}</span>
        ${role !== 'main' ? html`<span aria-hidden="true"> · </span><span>${role === 'open' ? 'Opening' : 'Closing'}</span>` : ''}
      </p>

      <div class="night__ring">
        <svg viewBox="0 0 100 100" aria-hidden="true" focusable="false">
          <circle class="night__track" cx="50" cy="50" r="46"/>
          <circle class="night__progress" data-el="ring" cx="50" cy="50" r="46"
                  stroke-dasharray="${RING.toFixed(2)}" stroke-dashoffset="0"/>
        </svg>
        <div class="night__clock-wrap">
          <div class="night__clock" role="timer" aria-live="off" aria-label="Time left in this moment" data-el="clock">${formatClock(blockLeft(night))}</div>
          <p class="night__paused" data-show-paused>${paused ? 'Paused' : `${it.minutes} min`}</p>
        </div>
      </div>

      <h1 class="night__title">${block.title}</h1>
      <p class="night__how">${block.howTo}</p>
      ${block.need?.length ? html`<p class="night__need"><span class="moment__need-label">You’ll need</span> ${block.need.join(' · ')}</p>` : ''}

      <div class="night__controls">
        <button class="btn btn--lux" type="button" data-action="${paused ? 'resume' : 'pause'}">
          ${icon(paused ? 'play' : 'pause', 'icon')} ${paused ? 'Resume' : 'Pause'}
        </button>
        <button class="btn btn--ghost" type="button" data-action="next">${icon('next', 'icon')} ${next ? 'Next' : 'Finish'}</button>
        <button class="btn btn--ghost" type="button" data-action="end" data-el="end">${icon('stop', 'icon')} <span data-el="end-label">End</span></button>
      </div>

      <p class="night__next text-muted">
        ${next ? html`Next: <span class="serif">${byId(next.id).title}</span> · ${next.minutes} min` : 'Last moment of the night.'}
      </p>

      <section class="night__sound" aria-labelledby="sound-title">
        <div class="row-between">
          <h2 class="eyebrow eyebrow--muted" id="sound-title">Ambience</h2>
          ${night.manualSound ? html`<button class="link-btn" type="button" data-action="auto-sound">Follow the plan</button>` : html`<span class="text-xs text-muted">Paired with this moment</span>`}
        </div>
        <div class="sound-row">
          ${ambient.SOUND_LIST.map((s) => html`
            <button class="sound-chip" type="button" data-sound="${s.id}" aria-pressed="${!muted && s.id === sound}">
              ${icon(s.id, 'icon')} <span>${s.label}</span>
            </button>`)}
          <button class="sound-chip sound-chip--mute" type="button" data-action="mute" aria-pressed="${muted}"
                  aria-label="${muted ? 'Unmute ambience' : 'Mute ambience'}">
            ${icon(muted ? 'mute' : 'volume', 'icon')} <span>${muted ? 'Muted' : 'Mute'}</span>
          </button>
        </div>
        <p class="text-xs text-muted">A soft chime marks each change${muted ? ', even while muted' : ''}.</p>
      </section>

      <p class="night__meta text-sm text-muted" data-el="meta"></p>
      <p class="night__awake text-xs text-muted" data-el="awake">${wakeText(wakeMode())}</p>

      <ol class="night__dots" aria-hidden="true">
        ${plan.items.map((_, i) => html`<li class="${i < index ? 'is-done' : i === index ? 'is-now' : ''}"></li>`)}
      </ol>
    </div>`;
}

function endTemplate(night, draft, favSaved) {
  const { plan } = night;
  const minutes = night.endedEarly ? Math.max(1, Math.round((night.endedAt - night.startedAt) / 60_000)) : plan.prefs.minutes;
  const entry = store.get().history.find((h) => h.id === night.historyId);
  const value = draft ?? entry?.reflection ?? '';
  return html`
    <div class="end fade-in" data-el="end-screen">
      <svg class="end__glyph" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
        <path d="M40 14a20 20 0 1 0 10 30 16 16 0 1 1-10-30z" fill="var(--c-accent)"/>
        <circle cx="48" cy="16" r="2" fill="var(--c-gold)"/><circle cx="14" cy="20" r="1.5" fill="var(--c-gold)"/>
      </svg>
      <p class="eyebrow">${planTitle(plan)}</p>
      <h1>Night complete</h1>
      <p class="end__lede serif">
        You gave yourself ${minutes} ${minutes === 1 ? 'minute' : 'minutes'}.
        ${night.endedEarly ? 'Ending a little early still counts.' : 'Every moment, start to finish.'}
      </p>

      <ol class="end__list">
        ${plan.items.map((it, i) => {
          const done = !night.endedEarly || i < night.index;
          const partly = night.endedEarly && i === night.index;
          return html`<li class="${done ? 'is-done' : partly ? 'is-partly' : ''}">
            <span class="end__mark" aria-hidden="true">${done ? icon('check', 'icon') : ''}</span>
            <span>${byId(it.id).title}</span>
            <span class="sr-only">${done ? 'done' : partly ? 'partly done' : 'not reached'}</span>
          </li>`;
        })}
      </ol>

      <form class="end__reflect card" data-el="reflect">
        <label class="field__label" for="reflection">One line about tonight</label>
        <div class="reflect-row">
          <input id="reflection" class="input" type="text" maxlength="160" autocomplete="off"
                 placeholder="What felt good?" value="${value}" data-el="reflection">
          <button class="btn" type="submit">Save</button>
        </div>
        <p class="text-xs text-muted" data-el="reflect-meta" aria-live="polite">${entry?.reflection ? 'Saved on this device.' : 'Kept only on this device.'}</p>
      </form>

      <div class="stack">
        <button class="btn btn--lux btn--block" type="button" data-action="again">Plan another night</button>
        <div class="grid-2">
          <button class="btn btn--ghost" type="button" data-action="favourite" aria-pressed="${favSaved}">
            ${icon(favSaved ? 'check' : 'heart', 'icon')} ${favSaved ? 'Saved' : 'Save this night'}
          </button>
          <a class="btn btn--ghost" href="#/nights" data-action="nights">My nights</a>
        </div>
      </div>
    </div>`;
}

export function mount(root, { navigate }) {
  syncNight();
  const initial = getNight();
  if (initial.status === 'idle') {
    navigate(store.get().plan ? '/plan' : '/');
    return undefined;
  }

  let stopWatch = null;
  let releaseLock = null;
  let confirmTimer = null;
  let favSaved = false;
  const offs = [];

  const ambientState = () => store.get().ambient;
  const el = (name) => qs(`[data-el="${name}"]`, root);

  function applySound(seconds = 3) {
    const night = getNight();
    if (night.status !== 'active') return;
    if (ambientState().muted) ambient.stopAll(0.6);
    else ambient.crossfadeTo(currentSound(night), seconds);
  }

  function tick() {
    const night = getNight();
    if (night.status !== 'active' && night.status !== 'paused') return;
    const left = blockLeft(night);
    const blockMs = night.plan.items[night.index].minutes * 60_000;
    el('clock').textContent = formatClock(left);
    el('ring')?.setAttribute('stroke-dashoffset', (RING * (1 - left / blockMs)).toFixed(2));
    const rest = nightLeft(night);
    el('meta').textContent = `Whole night: ${formatClock(rest)} left · ends around ${formatTime(Date.now() + rest)}`;
    document.title = `${formatClock(left)} · Solo Night`;
  }

  function startWatch() {
    stopWatch?.();
    stopWatch = null;
    const night = getNight();
    if (night.status !== 'active') {
      tick();
      return;
    }
    stopWatch = watchCountdown({ remaining: () => blockLeft(), onTick: tick, onComplete: onBlockEnd });
  }

  function cue() {
    ambient.chime();
    navigator.vibrate?.([90, 70, 90]);
  }

  function onBlockEnd() {
    const { advanced, completed } = syncNight();
    if (completed) return finished();
    if (advanced) {
      cue();
      applySound();
      paint();
      const night = getNight();
      const it = night.plan.items[night.index];
      announce(`Next: ${byId(it.id).title}, ${it.minutes} minutes.`);
    }
    startWatch();
  }

  function finished() {
    stopWatch?.();
    stopWatch = null;
    cue();
    ambient.fadeOutAll(30);
    releaseAwake();
    paint();
    announce('Night complete.');
  }

  function paint(focusAction) {
    const night = getNight();
    if (night.status === 'complete') {
      releaseLock?.();
      releaseLock = null;
      setRitualMode('complete');
      render(root, endTemplate(night, store.get().session.reflectionDraft || null, favSaved));
      document.title = 'Night complete · Solo Night Roulette';
      qs('h1', root)?.setAttribute('tabindex', '-1');
      qs('h1', root)?.focus();
      return;
    }
    setRitualMode('active');
    render(root, runningTemplate(night, ambientState()));
    tick();
    if (focusAction) qs(`[data-action="${focusAction}"], [data-sound="${focusAction}"]`, root)?.focus();
  }

  function catchUp() {
    ambient.wake();
    const { advanced, completed } = syncNight();
    if (completed) return finished();
    if (advanced) {
      cue();
      applySound();
      paint();
      announce(`Welcome back. Now: ${byId(getNight().plan.items[getNight().index].id).title}.`);
    }
    startWatch();
    return undefined;
  }

  const actions = {
    pause() {
      pauseNight();
      ambient.stopAll(0.5);
      paint('resume');
      startWatch();
      announce('Paused.');
    },
    resume() {
      resumeNight();
      applySound(1.5);
      paint('pause');
      startWatch();
      announce('Resumed.');
    },
    next() {
      const completed = skipBlock();
      if (completed) return finished();
      cue();
      applySound();
      paint('next');
      startWatch();
      const night = getNight();
      announce(`Now: ${byId(night.plan.items[night.index].id).title}.`);
      return undefined;
    },
    end(btn) {
      if (btn.dataset.confirm !== 'armed') {
        btn.dataset.confirm = 'armed';
        el('end-label').textContent = 'Tap again to end';
        announce('Press End again to finish the night early.');
        clearTimeout(confirmTimer);
        confirmTimer = setTimeout(() => {
          delete btn.dataset.confirm;
          const label = el('end-label');
          if (label) label.textContent = 'End';
        }, CONFIRM_MS);
        return;
      }
      clearTimeout(confirmTimer);
      endNight();
      finished();
    },
    mute() {
      const muted = !ambientState().muted;
      store.set(({ ambient: a }) => ({ ambient: { ...a, muted } }));
      if (muted) ambient.stopAll(0.6);
      else applySound(1.5);
      paint('mute');
      announce(muted ? 'Ambience muted.' : 'Ambience on.');
    },
    'auto-sound'() {
      store.set(({ night }) => ({ night: { ...night, manualSound: null } }));
      applySound();
      paint();
      qs('[aria-pressed="true"][data-sound]', root)?.focus();
    },
    again() {
      clearNight();
      store.set(({ session }) => ({ session: { ...session, reflectionDraft: '' } }));
      setRitualMode('idle');
      navigate('/');
    },
    favourite() {
      if (favSaved) return;
      saveFavourite(getNight().plan);
      favSaved = true;
      toast('Saved to My nights.');
      paint();
      qs('[data-action="favourite"]', root)?.focus();
    },
  };

  offs.push(on(root, 'click', '[data-action]', (event, btn) => {
    if (btn.dataset.action === 'nights') return; // a plain link
    actions[btn.dataset.action]?.(btn, event);
  }));
  offs.push(on(root, 'click', '[data-sound]', (_, btn) => {
    const id = btn.dataset.sound;
    store.set(({ night, ambient: a }) => ({ night: { ...night, manualSound: id }, ambient: { ...a, muted: false } }));
    if (getNight().status === 'active') ambient.crossfadeTo(id, 1.5);
    paint(id);
  }));

  // Reflection: saved on Save, on leaving the field, and when the app is hidden.
  const saveDraft = () => {
    const input = el('reflection');
    if (!input) return;
    store.set(({ session }) => ({ session: { ...session, reflectionDraft: input.value } }));
  };
  const commitReflection = () => {
    const input = el('reflection');
    if (!input) return;
    saveReflection(input.value);
    store.set(({ session }) => ({ session: { ...session, reflectionDraft: '' } }));
    el('reflect-meta').textContent = input.value.trim() ? 'Saved on this device.' : 'Kept only on this device.';
  };
  offs.push(on(root, 'submit', '[data-el="reflect"]', (event) => {
    event.preventDefault();
    commitReflection();
    toast('Saved. Sleep well.');
  }));
  offs.push(on(root, 'input', '[data-el="reflection"]', saveDraft));
  offs.push(on(root, 'focusout', '[data-el="reflection"]', (event) => {
    if (event.target.value.trim()) commitReflection();
  }));
  offs.push(onSuspend(() => {
    if (el('reflection')?.value.trim()) commitReflection();
  }));

  offs.push(onWakeChange((mode) => {
    const awake = el('awake');
    if (awake) awake.textContent = wakeText(mode);
  }));

  // First paint
  if (initial.status === 'active' || initial.status === 'paused') {
    releaseLock = engageLockdown({ onReturn: catchUp });
    if (initial.status === 'active') {
      keepAwake();
      if (!ambientState().muted && ambient.playing().length === 0) {
        // After a reload the browser needs a tap before sound can play.
        toast('Tap to bring the ambience back.', { action: 'Play', duration: 10000, onAction: () => applySound(1.5) });
      } else {
        applySound(1.5);
      }
    }
  }
  paint();
  startWatch();

  return () => {
    stopWatch?.();
    releaseLock?.();
    clearTimeout(confirmTimer);
    offs.forEach((off) => off());
    const night = getNight();
    if (night.status === 'complete' || night.status === 'idle') setRitualMode('idle');
    if (night.status === 'complete' && el('reflection')?.value.trim()) commitReflection();
  };
}
