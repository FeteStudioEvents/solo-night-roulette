import { announce, html, on, qs, render } from '../core/dom.js';
import { store } from '../core/store.js';
import { toast } from '../core/toast.js';
import { byId, hasBlock } from '../data/blocks.js';
import { clearHistory, removeFavourite, saveFavourite } from '../features/library.js';
import { getNight } from '../features/night-runner.js';
import { clonePlan, planMeta } from '../features/planner.js';
import { icon } from './icons.js';

export const title = 'My nights';

const dateLabel = (ms) => new Date(ms).toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' });
const titles = (items) => items.filter((it) => hasBlock(it.id)).map((it) => byId(it.id).title).join(' · ');

function favouriteCard(f) {
  return html`
    <li class="saved card" data-id="${f.id}">
      <p class="eyebrow">${planMeta(f.prefs)}</p>
      <h3 class="saved__name">${f.name}</h3>
      <p class="saved__blocks text-sm text-muted">${titles(f.items)}</p>
      <div class="saved__actions">
        <button class="btn" type="button" data-action="replay-fav" aria-label="Replay ${f.name}">${icon('play', 'icon')} Replay</button>
        <button class="btn btn--ghost" type="button" data-action="remove-fav" aria-label="Remove ${f.name} from favourites">Remove</button>
      </div>
    </li>`;
}

function historyCard(h) {
  return html`
    <li class="saved card" data-id="${h.id}">
      <div class="row-between">
        <p class="eyebrow">${dateLabel(h.at)}</p>
        <span class="chip">${h.completed ? 'Completed' : `Ended after ${h.minutesDone} min`}</span>
      </div>
      <h3 class="saved__name">${planMeta(h.prefs)}</h3>
      ${h.reflection ? html`<blockquote class="saved__quote serif">“${h.reflection}”</blockquote>` : ''}
      <p class="saved__blocks text-sm text-muted">${titles(h.items)}</p>
      <div class="saved__actions">
        <button class="btn" type="button" data-action="replay-history" aria-label="Replay the night from ${dateLabel(h.at)}">${icon('play', 'icon')} Replay</button>
        <button class="btn btn--ghost" type="button" data-action="fav-history" aria-label="Save the night from ${dateLabel(h.at)} as a favourite">${icon('heart', 'icon')} Favourite</button>
      </div>
    </li>`;
}

function template({ favourites, history }) {
  return html`
    <div class="nights">
      <header>
        <p class="eyebrow">Saved on this device</p>
        <h1>My nights</h1>
      </header>

      <section class="stack" aria-labelledby="fav-title">
        <h2 class="section-title" id="fav-title" tabindex="-1">Favourites</h2>
        ${favourites.length
          ? html`<ul class="saved-list">${favourites.map(favouriteCard)}</ul>`
          : html`<p class="empty text-muted">Nothing saved yet. When a spin feels just right, tap <strong>Save</strong> on your plan.</p>`}
      </section>

      <section class="stack" aria-labelledby="history-title">
        <div class="row-between">
          <h2 class="section-title" id="history-title" tabindex="-1">Recent nights</h2>
          ${history.length ? html`<button class="link-btn" type="button" data-action="clear-history" data-el="clear">Clear</button>` : ''}
        </div>
        ${history.length
          ? html`<ul class="saved-list">${history.map(historyCard)}</ul>`
          : html`<p class="empty text-muted">Your finished nights will appear here, with the line you wrote at the end.</p>`}
      </section>

      <p class="center"><a class="btn btn--lux" href="#/">Plan a new night</a></p>
    </div>`;
}

export function mount(root, { navigate }) {
  const paint = () => render(root, template(store.get()));
  let clearArmed = null;

  const find = (list, btn) => store.get()[list].find((x) => x.id === btn.closest('[data-id]').dataset.id);

  const replay = (saved) => {
    const night = getNight();
    if (night.status === 'active' || night.status === 'paused') {
      toast('A night is already in progress.');
      navigate('/night');
      return;
    }
    store.set({ plan: clonePlan(saved) });
    navigate('/plan');
  };

  const actions = {
    'replay-fav': (btn) => replay(find('favourites', btn)),
    'replay-history': (btn) => replay(find('history', btn)),
    'remove-fav': (btn) => {
      const fav = find('favourites', btn);
      removeFavourite(fav.id);
      paint();
      qs('#fav-title', root)?.focus();
      toast(`Removed “${fav.name}”.`, {
        action: 'Undo',
        onAction: () => {
          store.set(({ favourites }) => ({ favourites: [fav, ...favourites] }));
          paint();
        },
      });
    },
    'fav-history': (btn) => {
      const h = find('history', btn);
      saveFavourite(clonePlan(h));
      paint();
      toast('Saved to favourites.');
      qs('#fav-title', root)?.focus();
    },
    'clear-history': (btn) => {
      if (!clearArmed) {
        btn.textContent = 'Tap again to clear';
        announce('Press Clear again to delete your recent nights.');
        clearArmed = setTimeout(() => {
          clearArmed = null;
          if (btn.isConnected) btn.textContent = 'Clear';
        }, 4000);
        return;
      }
      clearTimeout(clearArmed);
      clearArmed = null;
      clearHistory();
      paint();
      announce('Recent nights cleared.');
      qs('#history-title', root)?.focus();
    },
  };

  const off = on(root, 'click', '[data-action]', (event, btn) => actions[btn.dataset.action]?.(btn, event));
  paint();
  return () => {
    off();
    clearTimeout(clearArmed);
  };
}
