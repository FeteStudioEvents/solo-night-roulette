import { qs } from './core/dom.js';
import { createRouter } from './core/router.js';
import { store } from './core/store.js';
import { registerServiceWorker } from './core/sw-register.js';
import { installHint, isStandalone } from './features/install.js';
import { getNight } from './features/night-runner.js';
import { applyTheme, setTheme } from './features/theme.js';

// Views load lazily so first paint only pays for the screen being shown.
const routes = {
  '/': () => import('./views/pick.js'),
  '/plan': () => import('./views/plan.js'),
  '/night': () => import('./views/night.js'),
  '/nights': () => import('./views/nights.js'),
};

applyTheme();

const router = createRouter({
  root: document.getElementById('view'),
  routes,
  notFound: () => import('./views/not-found.js'),
  onNavigate: (path) => {
    for (const link of document.querySelectorAll('[data-nav]')) {
      if (link.getAttribute('href') === `#${path}`) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    }
  },
});

// A night still running (the app was closed or reloaded mid-night) resumes where it is.
const night = getNight();
if ((night.status === 'active' || night.status === 'paused') && !location.hash.startsWith('#/night')) {
  history.replaceState(null, '', '#/night');
}

// The skip link targets #view; handle it here so the hash router does not treat it as a route.
qs('.skip-link').addEventListener('click', (event) => {
  event.preventDefault();
  const view = document.getElementById('view');
  view.focus();
  view.scrollIntoView();
});

setupAbout();
router.start();
registerServiceWorker();

/** The About sheet: privacy, appearance, install help, licence. */
function setupAbout() {
  const sheet = document.getElementById('about');
  const opener = qs('[data-action="about"]');
  const hint = qs('[data-el="about-install"]', sheet);
  const clearBtn = qs('[data-action="clear-data"]', sheet);
  let clearArmed = null;

  opener.addEventListener('click', () => {
    hint.textContent = isStandalone() ? 'Installed on this device. Lovely.' : installHint();
    const theme = store.get().ui.theme;
    for (const input of sheet.querySelectorAll('input[name="theme"]')) input.checked = input.value === theme;
    sheet.showModal();
  });
  sheet.addEventListener('click', (event) => {
    // A tap on the backdrop (outside the panel) closes the sheet.
    if (event.target === sheet) sheet.close();
  });
  qs('[data-action="close-about"]', sheet).addEventListener('click', () => sheet.close());
  sheet.addEventListener('close', () => opener.focus());
  sheet.addEventListener('change', (event) => {
    if (event.target.name === 'theme') setTheme(event.target.value);
  });
  clearBtn.addEventListener('click', () => {
    if (!clearArmed) {
      clearBtn.textContent = 'Tap again to delete everything';
      clearArmed = setTimeout(() => {
        clearArmed = null;
        clearBtn.textContent = 'Delete all my data';
      }, 4000);
      return;
    }
    clearTimeout(clearArmed);
    store.reset();
    try {
      localStorage.removeItem('snr:solo-night');
    } catch {
      // Storage blocked: nothing was saved anyway.
    }
    location.replace('./');
  });
}
